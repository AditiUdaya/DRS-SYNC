"use client"

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Upload, Download, Play, Pause, RotateCcw, Wifi, WifiOff, Activity } from 'lucide-react'

interface TransferStats {
  progress: number
  speed: string
  timeRemaining: string
  packetsSent: number
  packetsReceived: number
  lossRate: number
  rtt: number
  windowSize: number
  status: 'idle' | 'sending' | 'receiving' | 'completed' | 'error'
}

interface FileTransfer {
  id: string
  filename: string
  size: string
  progress: number
  status: 'pending' | 'active' | 'completed' | 'failed'
  type: 'upload' | 'download'
}

export default function Home() {
  const [stats, setStats] = useState<TransferStats>({
    progress: 0,
    speed: '0 B/s',
    timeRemaining: '--',
    packetsSent: 0,
    packetsReceived: 0,
    lossRate: 0,
    rtt: 0,
    windowSize: 10,
    status: 'idle'
  })

  const [transfers, setTransfers] = useState<FileTransfer[]>([])
  const [isConnected, setIsConnected] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)

  // Simulate real-time stats updates
  useEffect(() => {
    if (stats.status === 'sending' || stats.status === 'receiving') {
      const interval = setInterval(() => {
        setStats(prev => {
          const newProgress = Math.min(prev.progress + Math.random() * 5, 100)
          return {
            ...prev,
            progress: newProgress,
            speed: `${(Math.random() * 10 + 1).toFixed(1)} MB/s`,
            packetsSent: prev.packetsSent + Math.floor(Math.random() * 10),
            packetsReceived: prev.packetsReceived + Math.floor(Math.random() * 8),
            lossRate: Math.random() * 5,
            rtt: Math.random() * 100 + 20,
            status: newProgress >= 100 ? 'completed' : prev.status
          }
        })
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [stats.status])

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const startTransfer = () => {
    if (!selectedFile) return

    const newTransfer: FileTransfer = {
      id: Date.now().toString(),
      filename: selectedFile.name,
      size: `${(selectedFile.size / 1024 / 1024).toFixed(2)} MB`,
      progress: 0,
      status: 'active',
      type: 'upload'
    }

    setTransfers(prev => [...prev, newTransfer])
    setStats(prev => ({ ...prev, status: 'sending' }))
    setIsConnected(true)
  }

  const pauseTransfer = () => {
    setStats(prev => ({ ...prev, status: 'idle' }))
  }

  const resumeTransfer = () => {
    setStats(prev => ({ ...prev, status: 'sending' }))
  }

  const cancelTransfer = () => {
    setStats(prev => ({ ...prev, status: 'idle', progress: 0 }))
    setTransfers([])
    setSelectedFile(null)
    setIsConnected(false)
  }

  const simulateNetworkToggle = () => {
    setIsConnected(!isConnected)
    if (isConnected) {
      setStats(prev => ({ ...prev, status: 'error' }))
    } else {
      setStats(prev => ({ ...prev, status: 'sending' }))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-slate-900">UDP File Transfer</h1>
          <p className="text-lg text-slate-600">High-performance, resumable file transfer system</p>
          <div className="flex justify-center items-center gap-2">
            {isConnected ? (
              <Badge variant="default" className="bg-green-500">
                <Wifi className="w-4 h-4 mr-1" />
                Connected
              </Badge>
            ) : (
              <Badge variant="destructive">
                <WifiOff className="w-4 h-4 mr-1" />
                Disconnected
              </Badge>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Control Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* File Upload */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5" />
                  File Transfer
                </CardTitle>
                <CardDescription>
                  Select a file to start a high-speed UDP transfer
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <input
                    type="file"
                    onChange={handleFileSelect}
                    className="flex-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                  />
                  {selectedFile && (
                    <div className="text-sm text-slate-600">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </div>
                  )}
                </div>

                {selectedFile && (
                  <div className="space-y-2">
                    <Progress value={stats.progress} className="h-2" />
                    <div className="flex justify-between text-sm text-slate-600">
                      <span>{stats.progress.toFixed(1)}% complete</span>
                      <span>{stats.speed}</span>
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  {stats.status === 'idle' && (
                    <Button onClick={startTransfer} disabled={!selectedFile}>
                      <Play className="w-4 h-4 mr-2" />
                      Start Transfer
                    </Button>
                  )}
                  {(stats.status === 'sending' || stats.status === 'receiving') && (
                    <>
                      <Button onClick={pauseTransfer} variant="outline">
                        <Pause className="w-4 h-4 mr-2" />
                        Pause
                      </Button>
                      <Button onClick={cancelTransfer} variant="destructive">
                        Cancel
                      </Button>
                    </>
                  )}
                  {stats.status === 'error' && (
                    <Button onClick={resumeTransfer}>
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Resume
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Network Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Network Statistics
                </CardTitle>
                <CardDescription>
                  Real-time performance metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="performance" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="performance">Performance</TabsTrigger>
                    <TabsTrigger value="reliability">Reliability</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="performance" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Transfer Speed</p>
                        <p className="text-2xl font-bold text-blue-600">{stats.speed}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Time Remaining</p>
                        <p className="text-2xl font-bold text-green-600">{stats.timeRemaining}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Window Size</p>
                        <p className="text-2xl font-bold">{stats.windowSize}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">RTT</p>
                        <p className="text-2xl font-bold">{stats.rtt.toFixed(0)}ms</p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="reliability" className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Packets Sent</p>
                        <p className="text-2xl font-bold text-blue-600">{stats.packetsSent}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Packets Received</p>
                        <p className="text-2xl font-bold text-green-600">{stats.packetsReceived}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Loss Rate</p>
                        <p className="text-2xl font-bold text-red-600">{stats.lossRate.toFixed(1)}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">Retransmissions</p>
                        <p className="text-2xl font-bold text-orange-600">{Math.floor(stats.packetsSent * stats.lossRate / 100)}</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Demo Controls */}
            <Card>
              <CardHeader>
                <CardTitle>Demo Controls</CardTitle>
                <CardDescription>
                  Simulate network conditions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={simulateNetworkToggle} 
                  variant={isConnected ? "destructive" : "default"}
                  className="w-full"
                >
                  {isConnected ? (
                    <>
                      <WifiOff className="w-4 h-4 mr-2" />
                      Simulate Network Loss
                    </>
                  ) : (
                    <>
                      <Wifi className="w-4 h-4 mr-2" />
                      Restore Network
                    </>
                  )}
                </Button>
                
                <div className="text-sm text-slate-600 space-y-2">
                  <p><strong>Network Loss Demo:</strong></p>
                  <p>1. Start a file transfer</p>
                  <p>2. Click "Simulate Network Loss"</p>
                  <p>3. Watch transfer pause</p>
                  <p>4. Click "Restore Network"</p>
                  <p>5. Transfer resumes automatically!</p>
                </div>
              </CardContent>
            </Card>

            {/* Active Transfers */}
            <Card>
              <CardHeader>
                <CardTitle>Active Transfers</CardTitle>
                <CardDescription>
                  Current and recent transfers
                </CardDescription>
              </CardHeader>
              <CardContent>
                {transfers.length === 0 ? (
                  <p className="text-sm text-slate-500">No active transfers</p>
                ) : (
                  <div className="space-y-3">
                    {transfers.map((transfer) => (
                      <div key={transfer.id} className="border rounded-lg p-3">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium text-sm">{transfer.filename}</p>
                            <p className="text-xs text-slate-500">{transfer.size}</p>
                          </div>
                          <Badge variant={
                            transfer.status === 'completed' ? 'default' :
                            transfer.status === 'active' ? 'secondary' :
                            transfer.status === 'failed' ? 'destructive' : 'outline'
                          }>
                            {transfer.status}
                          </Badge>
                        </div>
                        <Progress value={transfer.progress} className="h-1" />
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Key Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Resumable transfers</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Adaptive congestion control</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Selective Repeat ARQ</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Real-time metrics</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Network resilience</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}