#!/bin/bash

# Demo script for UDP File Transfer System
# Shows resumable, reliable UDP file transfer capabilities

echo "🚀 UDP File Transfer Demo"
echo "========================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check if we're in the right directory
if [ ! -f "CMakeLists.txt" ]; then
    print_error "Please run this script from the cpp-backend directory"
    exit 1
fi

# Build the project
print_info "Building the project..."
if [ ! -d "build" ]; then
    mkdir build
fi

cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
if make -j$(sysctl -n hw.ncpu); then
    print_status "Build successful"
else
    print_error "Build failed"
    exit 1
fi

# Create test file
print_info "Creating test file..."
cd ..
dd if=/dev/urandom of=test_file.dat bs=1M count=10 2>/dev/null
print_status "Created 10MB test file"

# Demo 1: Basic reliable transfer
print_info "Demo 1: Basic Reliable Transfer"
echo "------------------------------------"

# Start receiver in background
print_info "Starting receiver..."
./build/udp_receiver_basic 8080 ./received &
RECEIVER_PID=$!

# Give receiver time to start
sleep 2

# Start sender
print_info "Starting sender..."
./build/udp_sender_basic test_file.dat 127.0.0.1 8080 &
SENDER_PID=$!

# Wait for transfer to complete
wait $SENDER_PID

# Stop receiver
kill $RECEIVER_PID 2>/dev/null
wait $RECEIVER_PID 2>/dev/null

# Verify file
if [ -f "./received/test_file.dat" ]; then
    ORIGINAL_SIZE=$(stat -f%z test_file.dat)
    RECEIVED_SIZE=$(stat -f%z ./received/test_file.dat)
    
    if [ "$ORIGINAL_SIZE" -eq "$RECEIVED_SIZE" ]; then
        print_status "File transfer successful - sizes match!"
    else
        print_error "File transfer failed - size mismatch"
    fi
else
    print_error "Received file not found"
fi

# Demo 2: Resume capability simulation
print_info "Demo 2: Resume Capability"
echo "-----------------------------"

# Create manifest with partial progress
print_info "Creating partial transfer scenario..."
mkdir -p manifests

# Start receiver
./build/udp_receiver_basic 8081 ./received_resume &
RECEIVER_PID=$!
sleep 2

# Start transfer but interrupt it
print_info "Starting transfer (will be interrupted)..."
timeout 5s ./build/udp_sender_basic test_file.dat 127.0.0.1 8081 || true

# Stop receiver
kill $RECEIVER_PID 2>/dev/null
wait $RECEIVER_PID 2>/dev/null

print_warning "Transfer interrupted - checking for resume capability..."

# Check if manifests were created
if [ -d "manifests" ] && [ "$(ls -A manifests)" ]; then
    print_status "Manifests created - resume capability available"
    ls -la manifests/
else
    print_warning "No manifests found"
fi

# Demo 3: Run unit tests
print_info "Demo 3: Running Unit Tests"
echo "-----------------------------"

cd build
if make test; then
    print_status "All tests passed!"
else
    print_error "Some tests failed"
fi

# Cleanup
print_info "Cleaning up..."
cd ..
rm -rf test_file.dat received received_resume manifests

print_status "Demo completed successfully!"
echo ""
print_info "Key Features Demonstrated:"
echo "  ✅ Reliable UDP file transfer"
echo "  ✅ Manifest-based progress tracking"
echo "  ✅ Unit test validation"
echo "  ✅ Resume capability foundation"
echo ""
print_info "Next Steps:"
echo "  🔄 Try interrupting transfers to test resume"
echo "  🌐 Test over real networks (not just localhost)"
echo "  📊 Add packet loss simulation"
echo "  🔧 Configure different window sizes and timeouts"