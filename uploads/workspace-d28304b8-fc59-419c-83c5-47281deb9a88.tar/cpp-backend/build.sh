#!/bin/bash

# Build script for UDP Transfer Backend on Mac

echo "🔨 Building UDP Transfer Backend..."

# Check if we're on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "❌ This script is designed for macOS"
    exit 1
fi

# Install dependencies if needed
echo "📦 Checking dependencies..."

# Check for Homebrew
if ! command -v brew &> /dev/null; then
    echo "❌ Homebrew not found. Please install Homebrew first."
    echo "   /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
    exit 1
fi

# Install nlohmann-json if not present
if ! brew list nlohmann-json &> /dev/null; then
    echo "📦 Installing nlohmann-json..."
    brew install nlohmann-json
fi

# Check for cmake
if ! command -v cmake &> /dev/null; then
    echo "📦 Installing cmake..."
    brew install cmake
fi

# Create build directory
mkdir -p build
cd build

# Configure with cmake
echo "⚙️  Configuring with CMake..."
cmake .. -DCMAKE_BUILD_TYPE=Release

# Build
echo "🔨 Building..."
make -j$(sysctl -n hw.ncpu)

# Run tests
echo "🧪 Running tests..."
if make test; then
    echo "✅ All tests passed!"
else
    echo "❌ Some tests failed"
    exit 1
fi

echo "✅ Build completed successfully!"
echo "📁 Build artifacts are in ./build/"
echo "🧪 Run tests with: cd build && make test"