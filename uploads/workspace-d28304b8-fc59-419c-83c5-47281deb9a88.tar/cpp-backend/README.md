# UDP File Transfer Backend

A high-performance, resumable, secure UDP-based file transfer system built in C++ for macOS.

## 🚀 Features Implemented

### ✅ Core Components
- **Manifest System** - JSON-based progress tracking for resumable transfers
- **Basic UDP Transport** - Raw packet sending and receiving
- **Reliable UDP** - Selective Repeat ARQ with sliding window
- **RTT Measurement** - Accurate round-trip time estimation
- **Fast Retransmit** - Quick recovery from packet loss
- **Resume Capability** - Continue interrupted transfers

### 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Application   │    │   Reliable UDP  │    │   Basic UDP     │
│   Layer         │◄──►│   (Selective    │◄──►│   Transport     │
│                 │    │   Repeat)       │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Manifest Mgr   │    │  Sliding Window │    │  Packet Format  │
│  (JSON-based)   │    │  & RTT Est.    │    │  & Validation   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 📦 Building on macOS

### Prerequisites
```bash
# Install dependencies with Homebrew
brew install cmake nlohmann-json
```

### Build
```bash
cd cpp-backend
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(sysctl -n hw.ncpu)
```

### Test
```bash
# Run all tests
make test

# Run individual tests
./test_manifest
./test_reliable
```

## 🧪 Demo Capabilities

### 1. Network OFF → ON Resume
```bash
# Terminal 1: Start receiver
./udp_receiver_basic 8080 ./received

# Terminal 2: Start sender
./udp_sender_basic large_file.txt 127.0.0.1 8080

# During transfer: Turn off WiFi, wait, turn back on
# Transfer automatically resumes!
```

### 2. High Packet Loss Simulation
```bash
# Simulate 30% packet loss (macOS)
sudo pfctl -a "com.apple" -f - <<EOF
scrub in on lo0 max-mss 1460
pass in quick on lo0 proto udp from any to any port 8080 probability 30%
EOF

# Run transfer - see adaptive retransmissions!
```

### 3. High Latency Simulation
```bash
# Add 200ms delay
sudo pfctl -a "com.apple" -f - <<EOF
scrub in on lo0 all
pass in quick on lo0 proto udp from any to any port 8080 keep state (max 2000, source-track rule, max-src-nodes 2000, max-src-states 2000) 
queue 1 on lo0 bandwidth 100Kb delay 200ms
EOF
```

## 📊 Usage Examples

### Basic Transfer
```cpp
#include "reliable/reliable_udp.h"

// Configure
transport::UdpConfig config;
config.remote_ip = "192.168.1.100";
config.remote_port = 8080;

reliable::ReliableConfig reliable_config;
reliable_config.window_size = 10;
reliable_config.enable_fast_retransmit = true;

// Create sender
reliable::ReliableUdpSender sender(config, reliable_config);

// Setup callbacks
sender.setProgressCallback([](double progress, uint32_t acked, uint32_t total) {
    std::cout << "Progress: " << (progress * 100) << "%" << std::endl;
});

sender.setCompletionCallback([](bool success) {
    std::cout << "Transfer " << (success ? "completed" : "failed") << std::endl;
});

// Start transfer
sender.start();
sender.sendFile("large_video.mp4", "192.168.1.100", 8080);
```

### Resume Transfer
```cpp
// Resume from manifest
reliable::ReliableUdpSender sender(config, reliable_config);
sender.start();
sender.resumeTransfer("manifest_file_id", "192.168.1.100", 8080);
```

## 🔧 Configuration

### Transport Configuration
```cpp
struct UdpConfig {
    std::string local_ip = "0.0.0.0";
    uint16_t local_port = 0;
    std::string remote_ip;
    uint16_t remote_port;
    uint32_t mtu = 1400;
    uint32_t socket_buffer_size = 1024 * 1024;
    uint32_t timeout_ms = 1000;
};
```

### Reliability Configuration
```cpp
struct ReliableConfig {
    uint32_t window_size = 10;
    uint32_t max_retries = 5;
    uint32_t timeout_ms = 1000;
    uint32_t max_timeout_ms = 10000;
    double rtt_alpha = 0.125;
    double rtt_beta = 0.25;
    uint32_t duplicate_ack_threshold = 3;
    bool enable_fast_retransmit = true;
    bool enable_congestion_control = false;
};
```

## 📈 Performance Metrics

### Real-time Statistics
- Packets sent/received
- Retransmissions
- RTT measurements
- Loss rate estimation
- Throughput calculation
- Window size tracking

### Example Output
```
📊 Transfer Statistics:
  Packets sent: 1250
  Packets received: 1198
  Bytes sent: 1.75 MB
  Throughput: 2.3 MB/s
  Loss rate: 4.2%
  Average RTT: 45.2 ms
  Fast retransmits: 12
  Timeouts: 3
```

## 🔄 Next Steps (Roadmap)

### 🟦 High Priority
- [ ] Sliding Window + Congestion Control
- [ ] WebSocket Metrics Layer
- [ ] Drogon REST API Integration
- [ ] Offline Queue System

### 🟩 Medium Priority
- [ ] Compression Module (zstd)
- [ ] Classic Encryption (AES-GCM)
- [ ] PQC Encryption (Kyber)

### 🟨 Low Priority
- [ ] Multipath Transport
- [ ] AI Optimizer
- [ ] Video Streaming Mode
- [ ] Documentation & CI/CD

## 🧪 Testing

### Run All Tests
```bash
cd build && make test
```

### Individual Tests
```bash
# Manifest system tests
./test_manifest

# Reliable UDP tests
./test_reliable
```

### Performance Testing
```bash
# Large file transfer test
./udp_sender_basic ~/Downloads/large_file.mp4 127.0.0.1 8080

# Resume capability test
# (Kill receiver mid-transfer, restart, see resume)
```

## 📁 Project Structure

```
cpp-backend/
├── src/
│   ├── manifest/          # Manifest system
│   │   ├── manifest.h
│   │   └── manifest.cpp
│   ├── transport/         # Basic UDP transport
│   │   ├── udp_transport.h
│   │   └── udp_transport.cpp
│   ├── reliable/          # Reliable UDP with SR
│   │   ├── reliable_udp.h
│   │   └── reliable_udp.cpp
│   ├── examples/          # Example applications
│   │   ├── udp_sender_basic.cpp
│   │   └── udp_receiver_basic.cpp
│   └── tests/             # Unit tests
│       ├── test_manifest.cpp
│       └── test_reliable.cpp
├── CMakeLists.txt
├── build.sh              # Build script for macOS
└── README.md
```

## 🎯 Key Demos for Investors

### 1. **Network Resilience Demo**
- Turn off WiFi mid-transfer
- Transfer pauses gracefully
- Turn WiFi back on
- Transfer resumes automatically from exact point

### 2. **Packet Loss Handling**
- Simulate 30% packet loss
- Watch adaptive retransmissions
- See throughput adaptation
- Transfer still completes successfully

### 3. **High Latency Networks**
- Add 200ms artificial delay
- Observe RTT estimation
- Watch timeout adjustments
- Maintain reliable delivery

### 4. **Speed Comparison**
- Compare vs TCP on same file
- Show UDP + reliability advantages
- Demonstrate lower overhead
- Better control over congestion

## 📝 License

This project is part of a comprehensive UDP file transfer system demonstration.

## 🤝 Contributing

This is a demonstration project showcasing advanced networking concepts in C++.

---

**Built with ❤️ for high-performance file transfers**