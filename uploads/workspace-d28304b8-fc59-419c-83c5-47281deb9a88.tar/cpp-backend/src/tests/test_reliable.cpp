#include "reliable/reliable_udp.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <filesystem>

using namespace transfer;

void test_reliable_transfer() {
    std::cout << "=== Testing Reliable UDP Transfer ===" << std::endl;

    // Create test file
    std::string test_file = "test_reliable.txt";
    std::ofstream file(test_file);
    for (int i = 0; i < 1000; ++i) {
        file << "This is line " << i << " of the reliable transfer test file.\n";
    }
    file.close();

    // Configure transport
    transport::UdpConfig sender_config;
    sender_config.local_port = 0;
    sender_config.remote_ip = "127.0.0.1";
    sender_config.remote_port = 8080;

    transport::UdpConfig receiver_config;
    receiver_config.local_ip = "127.0.0.1";
    receiver_config.local_port = 8080;

    // Configure reliability
    reliable::ReliableConfig reliable_config;
    reliable_config.window_size = 5;
    reliable_config.max_retries = 3;
    reliable_config.timeout_ms = 500;
    reliable_config.enable_fast_retransmit = true;

    // Create sender and receiver
    reliable::ReliableUdpSender sender(sender_config, reliable_config);
    reliable::ReliableUdpReceiver receiver(receiver_config, reliable_config);

    // Setup callbacks
    std::atomic<bool> transfer_completed{false};
    std::atomic<bool> file_received{false};

    sender.setProgressCallback([&](double progress, uint32_t acked, uint32_t total) {
        std::cout << "📈 Sender progress: " << (progress * 100) << "% (" 
                  << acked << "/" << total << ")" << std::endl;
    });

    sender.setCompletionCallback([&](bool success) {
        std::cout << (success ? "✅" : "❌") << " Sender transfer " 
                  << (success ? "completed" : "failed") << std::endl;
        transfer_completed = true;
    });

    receiver.setFileReceivedCallback([&](const std::string& filename, bool success) {
        std::cout << (success ? "✅" : "❌") << " Receiver file " << filename 
                  << " " << (success ? "received" : "failed") << std::endl;
        file_received = true;
    });

    receiver.setProgressCallback([&](const std::string& filename, double progress) {
        std::cout << "📈 Receiver progress for " << filename << ": " 
                  << (progress * 100) << "%" << std::endl;
    });

    // Start receiver
    if (!receiver.start("./received")) {
        std::cerr << "❌ Failed to start receiver" << std::endl;
        return;
    }

    // Give receiver time to start
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    // Start sender
    if (!sender.start()) {
        std::cerr << "❌ Failed to start sender" << std::endl;
        receiver.stop();
        return;
    }

    // Start transfer
    if (!sender.sendFile(test_file, "127.0.0.1", 8080)) {
        std::cerr << "❌ Failed to start transfer" << std::endl;
        sender.stop();
        receiver.stop();
        return;
    }

    // Wait for completion
    auto start_time = std::chrono::steady_clock::now();
    auto timeout = std::chrono::seconds(30);
    
    while ((!transfer_completed || !file_received) && 
           std::chrono::steady_clock::now() - start_time < timeout) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    // Print statistics
    auto sender_stats = sender.getStats();
    auto receiver_stats = receiver.getStats();

    std::cout << "\n📊 Sender Statistics:" << std::endl;
    std::cout << "  Packets retransmitted: " << sender_stats.packets_retransmitted << std::endl;
    std::cout << "  Fast retransmits: " << sender_stats.fast_retransmits << std::endl;
    std::cout << "  Timeouts: " << sender_stats.timeouts << std::endl;
    std::cout << "  Duplicate ACKs: " << sender_stats.duplicate_acks << std::endl;
    std::cout << "  Average RTT: " << sender_stats.average_rtt_ms << "ms" << std::endl;
    std::cout << "  Current RTO: " << sender_stats.current_rto_ms << "ms" << std::endl;

    std::cout << "\n📊 Receiver Statistics:" << std::endl;
    std::cout << "  Window size: " << receiver_stats.window_size << std::endl;
    std::cout << "  Throughput: " << transport::formatBytes(static_cast<uint64_t>(receiver_stats.throughput_bps)) << "/s" << std::endl;

    // Stop components
    sender.stop();
    receiver.stop();

    // Verify file
    std::string received_file = "./received/" + std::filesystem::path(test_file).filename().string();
    if (std::filesystem::exists(received_file)) {
        uint64_t original_size = std::filesystem::file_size(test_file);
        uint64_t received_size = std::filesystem::file_size(received_file);
        
        if (original_size == received_size) {
            std::cout << "✅ File size verification passed" << std::endl;
        } else {
            std::cout << "❌ File size verification failed: " 
                      << original_size << " vs " << received_size << std::endl;
        }
    } else {
        std::cout << "❌ Received file not found" << std::endl;
    }

    // Cleanup
    std::filesystem::remove(test_file);
    std::filesystem::remove_all("./received");

    bool success = transfer_completed && file_received;
    std::cout << "\n" << (success ? "✅" : "❌") << " Test " << (success ? "passed" : "failed") << std::endl;
}

void test_resume_transfer() {
    std::cout << "\n=== Testing Resume Transfer ===" << std::endl;

    // Create test file
    std::string test_file = "test_resume.txt";
    std::ofstream file(test_file);
    for (int i = 0; i < 500; ++i) {
        file << "Resume test line " << i << "\n";
    }
    file.close();

    // Configure transport
    transport::UdpConfig config;
    config.local_port = 0;
    config.remote_ip = "127.0.0.1";
    config.remote_port = 8081;

    reliable::ReliableConfig reliable_config;
    reliable_config.window_size = 3;
    reliable_config.max_retries = 2;

    // Create manifest manager to simulate partial transfer
    manifest::ManifestManager manager("./manifests");
    std::string file_id = manager.createManifest(test_file, 1024);

    // Mark some chunks as sent and some as acked
    auto manifest_opt = manager.loadManifest(file_id);
    if (manifest_opt) {
        const auto& manifest = *manifest_opt;
        
        // Mark first few chunks as sent
        for (uint32_t i = 0; i < std::min(5u, manifest.total_chunks); ++i) {
            manager.markChunkSent(file_id, i);
        }
        
        // Mark first few as acked
        for (uint32_t i = 0; i < std::min(3u, manifest.total_chunks); ++i) {
            manager.markChunkAcked(file_id, i);
        }
    }

    std::cout << "📊 Created partial manifest:" << std::endl;
    std::cout << "  File ID: " << file_id << std::endl;
    std::cout << "  Progress: " << (manager.getProgress(file_id) * 100) << "%" << std::endl;

    // Create sender and receiver
    reliable::ReliableUdpSender sender(config, reliable_config);
    reliable::ReliableUdpReceiver receiver(config, reliable_config);

    std::atomic<bool> transfer_completed{false};
    std::atomic<bool> file_received{false};

    sender.setCompletionCallback([&](bool success) {
        transfer_completed = true;
    });

    receiver.setFileReceivedCallback([&](const std::string& filename, bool success) {
        file_received = true;
    });

    // Start receiver
    receiver.start("./received_resume");
    std::this_thread::sleep_for(std::chrono::milliseconds(100));

    // Start sender
    sender.start();

    // Resume transfer
    if (!sender.resumeTransfer(file_id, "127.0.0.1", 8081)) {
        std::cerr << "❌ Failed to resume transfer" << std::endl;
        sender.stop();
        receiver.stop();
        return;
    }

    // Wait for completion
    auto start_time = std::chrono::steady_clock::now();
    auto timeout = std::chrono::seconds(20);
    
    while ((!transfer_completed || !file_received) && 
           std::chrono::steady_clock::now() - start_time < timeout) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    sender.stop();
    receiver.stop();

    // Cleanup
    std::filesystem::remove(test_file);
    std::filesystem::remove_all("./received_resume");
    std::filesystem::remove_all("./manifests");

    bool success = transfer_completed && file_received;
    std::cout << (success ? "✅" : "❌") << " Resume test " << (success ? "passed" : "failed") << std::endl;
}

int main() {
    std::cout << "🧪 Reliable UDP Tests" << std::endl;
    
    try {
        test_reliable_transfer();
        test_resume_transfer();
        
        std::cout << "\n✅ All tests completed!" << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "\n❌ Test failed: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}