#include "manifest/manifest.h"
#include <iostream>
#include <cassert>
#include <filesystem>
#include <fstream>

using namespace transfer::manifest;

void test_manifest_creation() {
    std::cout << "Testing manifest creation..." << std::endl;
    
    // Create a test file
    std::string test_file = "test_file.txt";
    std::ofstream file(test_file);
    file << "This is a test file for manifest system.";
    file.close();
    
    ManifestManager manager("./test_manifests");
    
    // Create manifest
    std::string file_id = manager.createManifest(test_file, 1024);
    assert(!file_id.empty());
    assert(manager.manifestExists(file_id));
    
    std::cout << "✓ Manifest created with ID: " << file_id << std::endl;
    
    // Load manifest
    auto manifest_opt = manager.loadManifest(file_id);
    assert(manifest_opt.has_value());
    
    const auto& manifest = *manifest_opt;
    assert(manifest.filename == "test_file.txt");
    assert(manifest.total_size > 0);
    assert(manifest.total_chunks > 0);
    assert(manifest.chunks.size() == manifest.total_chunks);
    
    std::cout << "✓ Manifest loaded successfully" << std::endl;
    std::cout << "  File: " << manifest.filename << std::endl;
    std::cout << "  Size: " << manifest.total_size << " bytes" << std::endl;
    std::cout << "  Chunks: " << manifest.total_chunks << std::endl;
    
    // Cleanup
    std::filesystem::remove(test_file);
    manager.deleteManifest(file_id);
    std::filesystem::remove_all("./test_manifests");
}

void test_chunk_tracking() {
    std::cout << "\nTesting chunk tracking..." << std::endl;
    
    // Create a larger test file
    std::string test_file = "test_chunk_file.txt";
    std::ofstream file(test_file);
    for (int i = 0; i < 1000; ++i) {
        file << "This is line " << i << " of the test file.\n";
    }
    file.close();
    
    ManifestManager manager("./test_manifests");
    std::string file_id = manager.createManifest(test_file, 512);
    
    auto manifest_opt = manager.loadManifest(file_id);
    assert(manifest_opt.has_value());
    
    // Test initial state
    auto pending = manager.getPendingChunks(file_id);
    auto sent = manager.getSentChunks(file_id);
    auto failed = manager.getFailedChunks(file_id);
    
    assert(pending.size() == manifest_opt->total_chunks);
    assert(sent.empty());
    assert(failed.empty());
    
    std::cout << "✓ Initial state: " << pending.size() << " pending chunks" << std::endl;
    
    // Mark some chunks as sent
    assert(manager.markChunkSent(file_id, 0));
    assert(manager.markChunkSent(file_id, 1));
    assert(manager.markChunkSent(file_id, 2));
    
    pending = manager.getPendingChunks(file_id);
    sent = manager.getSentChunks(file_id);
    
    assert(pending.size() == manifest_opt->total_chunks - 3);
    assert(sent.size() == 3);
    
    std::cout << "✓ After marking 3 chunks as sent: " << pending.size() << " pending, " << sent.size() << " sent" << std::endl;
    
    // Mark some chunks as acked
    assert(manager.markChunkAcked(file_id, 0));
    assert(manager.markChunkAcked(file_id, 1));
    
    sent = manager.getSentChunks(file_id);
    auto acked = manager.getProgress(file_id) * manifest_opt->total_chunks;
    
    assert(sent.size() == 1);  // Only chunk 2 should still be sent
    assert(acked == 2.0);     // Chunks 0 and 1 should be acked
    
    std::cout << "✓ After marking 2 chunks as acked: " << sent.size() << " sent, " << acked << " acked" << std::endl;
    
    // Test progress
    double progress = manager.getProgress(file_id);
    assert(progress == 2.0 / manifest_opt->total_chunks);
    
    std::cout << "✓ Progress: " << (progress * 100) << "%" << std::endl;
    
    // Cleanup
    std::filesystem::remove(test_file);
    manager.deleteManifest(file_id);
    std::filesystem::remove_all("./test_manifests");
}

void test_persistence() {
    std::cout << "\nTesting persistence..." << std::endl;
    
    // Create test file
    std::string test_file = "test_persistence.txt";
    std::ofstream file(test_file);
    file << "Persistence test data";
    file.close();
    
    std::string file_id;
    {
        ManifestManager manager("./test_manifests");
        file_id = manager.createManifest(test_file, 256);
        
        // Make some changes
        manager.markChunkSent(file_id, 0);
        manager.markChunkAcked(file_id, 0);
    }
    
    // Create new manager instance (simulates restart)
    {
        ManifestManager manager("./test_manifests");
        assert(manager.manifestExists(file_id));
        
        auto manifest_opt = manager.loadManifest(file_id);
        assert(manifest_opt.has_value());
        
        // Changes should be persisted
        auto pending = manager.getPendingChunks(file_id);
        auto sent = manager.getSentChunks(file_id);
        double progress = manager.getProgress(file_id);
        
        assert(pending.size() == manifest_opt->total_chunks - 1);
        assert(sent.empty());
        assert(progress > 0);
        
        std::cout << "✓ Persistence successful: " << pending.size() << " pending, progress " << (progress * 100) << "%" << std::endl;
    }
    
    // Cleanup
    std::filesystem::remove(test_file);
    std::filesystem::remove_all("./test_manifests");
}

void test_statistics() {
    std::cout << "\nTesting statistics..." << std::endl;
    
    // Create test file
    std::string test_file = "test_stats.txt";
    std::ofstream file(test_file);
    for (int i = 0; i < 100; ++i) {
        file << "Line " << i << "\n";
    }
    file.close();
    
    ManifestManager manager("./test_manifests");
    std::string file_id = manager.createManifest(test_file, 128);
    
    // Update statistics
    manager.updateStatistics(file_id);
    
    auto manifest_opt = manager.loadManifest(file_id);
    assert(manifest_opt.has_value());
    
    const auto& manifest = *manifest_opt;
    assert(manifest.chunks_pending == manifest.total_chunks);
    assert(manifest.chunks_sent == 0);
    assert(manifest.chunks_acked == 0);
    assert(manifest.chunks_failed == 0);
    assert(manifest.progress == 0.0);
    
    std::cout << "✓ Initial statistics:" << std::endl;
    std::cout << "  Pending: " << manifest.chunks_pending << std::endl;
    std::cout << "  Sent: " << manifest.chunks_sent << std::endl;
    std::cout << "  Acked: " << manifest.chunks_acked << std::endl;
    std::cout << "  Failed: " << manifest.chunks_failed << std::endl;
    std::cout << "  Progress: " << (manifest.progress * 100) << "%" << std::endl;
    
    // Mark some chunks and update
    manager.markChunkSent(file_id, 0);
    manager.markChunkAcked(file_id, 0);
    manager.markChunkFailed(file_id, 1);
    manager.updateStatistics(file_id);
    
    manifest_opt = manager.loadManifest(file_id);
    const auto& updated_manifest = *manifest_opt;
    
    assert(updated_manifest.chunks_pending == updated_manifest.total_chunks - 2);
    assert(updated_manifest.chunks_sent == 0);
    assert(updated_manifest.chunks_acked == 1);
    assert(updated_manifest.chunks_failed == 1);
    assert(updated_manifest.progress > 0);
    
    std::cout << "✓ Updated statistics:" << std::endl;
    std::cout << "  Pending: " << updated_manifest.chunks_pending << std::endl;
    std::cout << "  Sent: " << updated_manifest.chunks_sent << std::endl;
    std::cout << "  Acked: " << updated_manifest.chunks_acked << std::endl;
    std::cout << "  Failed: " << updated_manifest.chunks_failed << std::endl;
    std::cout << "  Progress: " << (updated_manifest.progress * 100) << "%" << std::endl;
    
    // Cleanup
    std::filesystem::remove(test_file);
    manager.deleteManifest(file_id);
    std::filesystem::remove_all("./test_manifests");
}

int main() {
    std::cout << "=== Manifest System Tests ===" << std::endl;
    
    try {
        test_manifest_creation();
        test_chunk_tracking();
        test_persistence();
        test_statistics();
        
        std::cout << "\n✅ All tests passed!" << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "\n❌ Test failed: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}