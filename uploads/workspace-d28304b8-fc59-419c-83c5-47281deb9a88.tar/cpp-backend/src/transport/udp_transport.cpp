#include "udp_transport.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <chrono>

namespace transfer {
namespace transport {

constexpr uint32_t PACKET_MAGIC = 0xDEADBEEF;
constexpr size_t MAX_PACKET_SIZE = 1500;  // Standard Ethernet MTU
constexpr size_t PACKET_HEADER_SIZE = sizeof(PacketHeader);

UdpTransport::UdpTransport(const UdpConfig& config) 
    : config_(config), socket_fd_(-1) {
    stats_.start_time = std::chrono::steady_clock::now();
    stats_.last_update = stats_.start_time;
}

UdpTransport::~UdpTransport() {
    stop();
}

bool UdpTransport::start() {
    if (running_.load()) {
        return true;
    }

    std::cout << "🚀 Starting UDP transport on " << config_.local_ip 
              << ":" << config_.local_port << " -> " 
              << config_.remote_ip << ":" << config_.remote_port << std::endl;

    if (!createSocket()) {
        handleError("Failed to create socket");
        return false;
    }

    if (!bindSocket()) {
        handleError("Failed to bind socket");
        close(socket_fd_);
        socket_fd_ = -1;
        return false;
    }

    if (!setupSocketOptions()) {
        handleError("Failed to setup socket options");
        close(socket_fd_);
        socket_fd_ = -1;
        return false;
    }

    // Setup remote address
    memset(&remote_addr_, 0, sizeof(remote_addr_));
    remote_addr_.sin_family = AF_INET;
    remote_addr_.sin_port = htons(config_.remote_port);
    if (inet_pton(AF_INET, config_.remote_ip.c_str(), &remote_addr_.sin_addr) <= 0) {
        handleError("Invalid remote IP address");
        close(socket_fd_);
        socket_fd_ = -1;
        return false;
    }

    running_.store(true);

    // Start threads
    receive_thread_ = std::thread(&UdpTransport::receiveLoop, this);
    stats_thread_ = std::thread(&UdpTransport::statsLoop, this);

    std::cout << "✅ UDP transport started successfully" << std::endl;
    return true;
}

void UdpTransport::stop() {
    if (!running_.load()) {
        return;
    }

    std::cout << "🛑 Stopping UDP transport..." << std::endl;
    running_.store(false);

    // Close socket to unblock receive thread
    if (socket_fd_ >= 0) {
        close(socket_fd_);
        socket_fd_ = -1;
    }

    // Join threads
    if (receive_thread_.joinable()) {
        receive_thread_.join();
    }
    if (stats_thread_.joinable()) {
        stats_thread_.join();
    }

    std::cout << "✅ UDP transport stopped" << std::endl;
}

bool UdpTransport::sendData(const std::string& file_id, uint32_t chunk_id, 
                            const uint8_t* data, size_t size) {
    if (!running_.load() || socket_fd_ < 0) {
        return false;
    }

    if (size > config_.mtu - PACKET_HEADER_SIZE) {
        handleError("Data size exceeds MTU");
        return false;
    }

    auto packet = createPacket(PacketType::DATA, file_id, chunk_id, data, size);
    
    ssize_t sent = sendto(socket_fd_, packet.data(), packet.size(), 0,
                         (struct sockaddr*)&remote_addr_, sizeof(remote_addr_));
    
    if (sent < 0) {
        handleError("Send failed: " + std::string(strerror(errno)));
        return false;
    }

    // Update statistics
    {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.packets_sent++;
        stats_.bytes_sent += sent;
    }

    return true;
}

bool UdpTransport::sendAck(const std::string& file_id, uint32_t chunk_id,
                          uint32_t window_size, double rtt_ms) {
    if (!running_.load() || socket_fd_ < 0) {
        return false;
    }

    auto packet = createPacket(PacketType::ACK, file_id, chunk_id);
    
    // Add ACK-specific fields
    auto* header = reinterpret_cast<PacketHeader*>(packet.data());
    header->size = window_size;
    
    // Store RTT in timestamp field for ACK packets
    *reinterpret_cast<double*>(&header->timestamp) = rtt_ms;
    
    ssize_t sent = sendto(socket_fd_, packet.data(), packet.size(), 0,
                         (struct sockaddr*)&remote_addr_, sizeof(remote_addr_));
    
    if (sent < 0) {
        handleError("Send ACK failed: " + std::string(strerror(errno)));
        return false;
    }

    // Update statistics
    {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.packets_sent++;
        stats_.bytes_sent += sent;
    }

    return true;
}

bool UdpTransport::sendHandshake(const std::string& file_id, const std::string& filename,
                                uint64_t file_size, uint32_t chunk_size, uint32_t total_chunks) {
    if (!running_.load() || socket_fd_ < 0) {
        return false;
    }

    // Create handshake packet with file metadata
    std::vector<uint8_t> metadata(sizeof(HandshakePacket));
    auto* hs_packet = reinterpret_cast<HandshakePacket*>(metadata.data());
    
    // Fill header
    hs_packet->magic = PACKET_MAGIC;
    hs_packet->type = PacketType::HANDSHAKE;
    hs_packet->file_id_hash = hashFileId(file_id);
    hs_packet->chunk_id = 0;
    hs_packet->seq_num = 0;
    hs_packet->size = metadata.size() - PACKET_HEADER_SIZE;
    hs_packet->timestamp = getCurrentTimestamp();
    
    // Fill handshake data
    strncpy(hs_packet->filename, filename.c_str(), sizeof(hs_packet->filename) - 1);
    hs_packet->filename[sizeof(hs_packet->filename) - 1] = '\0';
    hs_packet->file_size = file_size;
    hs_packet->chunk_size = chunk_size;
    hs_packet->total_chunks = total_chunks;
    hs_packet->checksum = calculateChecksum(metadata.data(), metadata.size());
    
    ssize_t sent = sendto(socket_fd_, metadata.data(), metadata.size(), 0,
                         (struct sockaddr*)&remote_addr_, sizeof(remote_addr_));
    
    if (sent < 0) {
        handleError("Send handshake failed: " + std::string(strerror(errno)));
        return false;
    }

    // Update statistics
    {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.packets_sent++;
        stats_.bytes_sent += sent;
    }

    return true;
}

TransportStats UdpTransport::getStats() const {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    return stats_;
}

void UdpTransport::resetStats() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    stats_ = TransportStats{};
    stats_.start_time = std::chrono::steady_clock::now();
    stats_.last_update = stats_.start_time;
}

void UdpTransport::updateConfig(const UdpConfig& config) {
    config_ = config;
    // Note: In a real implementation, you might want to restart the transport
    // with the new configuration
}

void UdpTransport::receiveLoop() {
    uint8_t buffer[MAX_PACKET_SIZE];
    struct sockaddr_in from_addr;
    socklen_t from_len = sizeof(from_addr);

    std::cout << "📡 Receive loop started" << std::endl;

    while (running_.load()) {
        ssize_t received = recvfrom(socket_fd_, buffer, sizeof(buffer), 0,
                                   (struct sockaddr*)&from_addr, &from_len);
        
        if (received < 0) {
            if (errno != EINTR && errno != EAGAIN) {
                handleError("Receive error: " + std::string(strerror(errno)));
            }
            continue;
        }

        // Update statistics
        {
            std::lock_guard<std::mutex> lock(stats_mutex_);
            stats_.packets_received++;
            stats_.bytes_received += received;
        }

        // Process packet
        processPacket(buffer, received, from_addr);
    }

    std::cout << "📡 Receive loop stopped" << std::endl;
}

void UdpTransport::statsLoop() {
    while (running_.load()) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        
        if (!running_.load()) break;

        // Calculate loss rate and throughput
        auto now = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
            now - stats_.start_time).count();
        
        {
            std::lock_guard<std::mutex> lock(stats_mutex_);
            
            if (stats_.packets_sent > 0) {
                stats_.loss_rate = static_cast<double>(stats_.packets_dropped) / 
                                  (stats_.packets_sent + stats_.packets_dropped);
            }
            
            if (duration > 0) {
                stats_.throughput_bps = (stats_.bytes_received * 1000.0) / duration;
            }
            
            stats_.last_update = now;
        }

        // Call stats callback
        if (stats_callback_) {
            stats_callback_(getStats());
        }
    }
}

void UdpTransport::processPacket(const uint8_t* buffer, size_t size,
                                 const struct sockaddr_in& from_addr) {
    if (size < PACKET_HEADER_SIZE) {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.packets_dropped++;
        return;
    }

    auto* header = reinterpret_cast<const PacketHeader*>(buffer);
    
    // Validate packet
    if (!validatePacket(header, size)) {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.packets_dropped++;
        return;
    }

    // Process based on packet type
    switch (header->type) {
        case PacketType::DATA: {
            if (data_callback_) {
                auto* data_packet = reinterpret_cast<const DataPacket*>(buffer);
                data_callback_(data_packet, size);
            }
            break;
        }
        case PacketType::ACK: {
            if (ack_callback_) {
                auto* ack_packet = reinterpret_cast<const AckPacket*>(buffer);
                ack_callback_(ack_packet);
            }
            break;
        }
        case PacketType::HANDSHAKE: {
            std::cout << "🤝 Received handshake packet" << std::endl;
            break;
        }
        case PacketType::HEARTBEAT: {
            // Handle heartbeat
            break;
        }
        case PacketType::ERROR: {
            std::cout << "❌ Received error packet" << std::endl;
            break;
        }
        default: {
            std::cout << "⚠️  Unknown packet type: " << static_cast<int>(header->type) << std::endl;
            break;
        }
    }
}

bool UdpTransport::createSocket() {
    socket_fd_ = socket(AF_INET, SOCK_DGRAM, 0);
    if (socket_fd_ < 0) {
        handleError("Socket creation failed: " + std::string(strerror(errno)));
        return false;
    }
    return true;
}

bool UdpTransport::bindSocket() {
    memset(&local_addr_, 0, sizeof(local_addr_));
    local_addr_.sin_family = AF_INET;
    local_addr_.sin_port = htons(config_.local_port);
    
    if (config_.local_ip == "0.0.0.0") {
        local_addr_.sin_addr.s_addr = INADDR_ANY;
    } else {
        if (inet_pton(AF_INET, config_.local_ip.c_str(), &local_addr_.sin_addr) <= 0) {
            handleError("Invalid local IP address");
            return false;
        }
    }

    if (bind(socket_fd_, (struct sockaddr*)&local_addr_, sizeof(local_addr_)) < 0) {
        handleError("Bind failed: " + std::string(strerror(errno)));
        return false;
    }

    return true;
}

bool UdpTransport::setupSocketOptions() {
    int reuse = 1;
    if (setsockopt(socket_fd_, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0) {
        handleError("Set SO_REUSEADDR failed: " + std::string(strerror(errno)));
        return false;
    }

    // Set socket buffer sizes
    if (setsockopt(socket_fd_, SOL_SOCKET, SO_RCVBUF, 
                   &config_.socket_buffer_size, sizeof(config_.socket_buffer_size)) < 0) {
        std::cout << "⚠️  Warning: Failed to set receive buffer size" << std::endl;
    }

    if (setsockopt(socket_fd_, SOL_SOCKET, SO_SNDBUF, 
                   &config_.socket_buffer_size, sizeof(config_.socket_buffer_size)) < 0) {
        std::cout << "⚠️  Warning: Failed to set send buffer size" << std::endl;
    }

    // Set timeouts
    struct timeval tv;
    tv.tv_sec = config_.recv_timeout_ms / 1000;
    tv.tv_usec = (config_.recv_timeout_ms % 1000) * 1000;
    if (setsockopt(socket_fd_, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0) {
        std::cout << "⚠️  Warning: Failed to set receive timeout" << std::endl;
    }

    tv.tv_sec = config_.send_timeout_ms / 1000;
    tv.tv_usec = (config_.send_timeout_ms % 1000) * 1000;
    if (setsockopt(socket_fd_, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv)) < 0) {
        std::cout << "⚠️  Warning: Failed to set send timeout" << std::endl;
    }

    return true;
}

uint32_t UdpTransport::calculateChecksum(const uint8_t* data, size_t size) {
    uint32_t checksum = 0;
    for (size_t i = 0; i < size; ++i) {
        checksum += data[i];
    }
    return checksum;
}

uint32_t UdpTransport::hashFileId(const std::string& file_id) {
    uint32_t hash = 5381;
    for (char c : file_id) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

uint64_t UdpTransport::getCurrentTimestamp() {
    auto now = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        now.time_since_epoch()).count();
}

std::vector<uint8_t> UdpTransport::createPacket(PacketType type, const std::string& file_id,
                                               uint32_t chunk_id, const uint8_t* data,
                                               size_t data_size) {
    std::vector<uint8_t> packet(PACKET_HEADER_SIZE + data_size);
    auto* header = reinterpret_cast<PacketHeader*>(packet.data());
    
    // Fill header
    header->magic = PACKET_MAGIC;
    header->type = type;
    header->file_id_hash = hashFileId(file_id);
    header->chunk_id = chunk_id;
    header->seq_num = 0;  // Will be set by reliable transport
    header->size = data_size;
    header->timestamp = getCurrentTimestamp();
    
    // Copy data if provided
    if (data && data_size > 0) {
        std::memcpy(packet.data() + PACKET_HEADER_SIZE, data, data_size);
    }
    
    // Calculate checksum
    header->checksum = calculateChecksum(packet.data(), packet.size());
    
    return packet;
}

void UdpTransport::handleError(const std::string& error) {
    std::cerr << "❌ UDP Transport Error: " << error << std::endl;
    if (error_callback_) {
        error_callback_(error);
    }
}

// Utility functions
std::string packetTypeToString(PacketType type) {
    switch (type) {
        case PacketType::DATA: return "DATA";
        case PacketType::ACK: return "ACK";
        case PacketType::NACK: return "NACK";
        case PacketType::HANDSHAKE: return "HANDSHAKE";
        case PacketType::HEARTBEAT: return "HEARTBEAT";
        case PacketType::ERROR: return "ERROR";
        default: return "UNKNOWN";
    }
}

bool validatePacket(const PacketHeader* header, size_t packet_size) {
    if (header->magic != PACKET_MAGIC) {
        return false;
    }
    
    if (header->size + sizeof(PacketHeader) != packet_size) {
        return false;
    }
    
    return true;
}

std::string formatBytes(uint64_t bytes) {
    const char* units[] = {"B", "KB", "MB", "GB", "TB"};
    int unit = 0;
    double size = static_cast<double>(bytes);
    
    while (size >= 1024.0 && unit < 4) {
        size /= 1024.0;
        unit++;
    }
    
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "%.2f %s", size, units[unit]);
    return std::string(buffer);
}

std::string formatTime(double ms) {
    if (ms < 1000.0) {
        return std::to_string(static_cast<int>(ms)) + "ms";
    } else if (ms < 60000.0) {
        return std::to_string(static_cast<int>(ms / 1000.0)) + "s";
    } else {
        int minutes = static_cast<int>(ms / 60000.0);
        int seconds = static_cast<int>((ms - minutes * 60000.0) / 1000.0);
        return std::to_string(minutes) + "m " + std::to_string(seconds) + "s";
    }
}

} // namespace transport
} // namespace transfer