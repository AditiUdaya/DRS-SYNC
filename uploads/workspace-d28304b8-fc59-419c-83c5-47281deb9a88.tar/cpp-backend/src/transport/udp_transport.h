#pragma once
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <atomic>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <chrono>

namespace transfer {
namespace transport {

// Packet types
enum class PacketType : uint8_t {
    DATA = 0x01,
    ACK = 0x02,
    NACK = 0x03,
    HANDSHAKE = 0x04,
    HEARTBEAT = 0x05,
    ERROR = 0x06
};

// Packet structure
#pragma pack(push, 1)
struct PacketHeader {
    uint32_t magic;        // 0xDEADBEEF
    PacketType type;       // Packet type
    uint32_t file_id_hash; // Hash of file ID for identification
    uint32_t chunk_id;     // Chunk identifier
    uint32_t seq_num;      // Sequence number
    uint32_t size;         // Data size
    uint64_t timestamp;    // Timestamp (nanoseconds)
    uint32_t checksum;     // Simple checksum
};

struct DataPacket : public PacketHeader {
    uint8_t data[];        // Variable length data
};

struct AckPacket : public PacketHeader {
    uint32_t window_size;  // Receiver window size
    double rtt_ms;        // Measured RTT
};

struct HandshakePacket : public PacketHeader {
    char filename[256];   // Filename
    uint64_t file_size;   // Total file size
    uint32_t chunk_size;  // Chunk size
    uint32_t total_chunks; // Total number of chunks
};
#pragma pack(pop)

// Configuration
struct UdpConfig {
    std::string local_ip = "0.0.0.0";
    uint16_t local_port = 0;
    std::string remote_ip;
    uint16_t remote_port;
    uint32_t mtu = 1400;           // Maximum transmission unit
    uint32_t socket_buffer_size = 1024 * 1024; // 1MB
    uint32_t send_timeout_ms = 1000;
    uint32_t recv_timeout_ms = 1000;
    bool enable_broadcast = false;
    bool enable_multicast = false;
    std::string multicast_group;
};

// Statistics
struct TransportStats {
    uint64_t packets_sent = 0;
    uint64_t packets_received = 0;
    uint64_t bytes_sent = 0;
    uint64_t bytes_received = 0;
    uint64_t packets_dropped = 0;
    double loss_rate = 0.0;
    double rtt_ms = 0.0;
    double throughput_bps = 0.0;
    std::chrono::steady_clock::time_point start_time;
    std::chrono::steady_clock::time_point last_update;
};

// Callback types
using DataCallback = std::function<void(const DataPacket* packet, size_t size)>;
using AckCallback = std::function<void(const AckPacket* packet)>;
using ErrorCallback = std::function<void(const std::string& error)>;
using StatsCallback = std::function<void(const TransportStats& stats)>;

class UdpTransport {
public:
    UdpTransport(const UdpConfig& config);
    ~UdpTransport();

    // Connection management
    bool start();
    void stop();
    bool isRunning() const { return running_.load(); }

    // Basic send/receive
    bool sendData(const std::string& file_id, uint32_t chunk_id, 
                 const uint8_t* data, size_t size);
    bool sendAck(const std::string& file_id, uint32_t chunk_id, 
                 uint32_t window_size = 0, double rtt_ms = 0.0);
    bool sendHandshake(const std::string& file_id, const std::string& filename,
                      uint64_t file_size, uint32_t chunk_size, uint32_t total_chunks);

    // Callbacks
    void setDataCallback(DataCallback callback) { data_callback_ = callback; }
    void setAckCallback(AckCallback callback) { ack_callback_ = callback; }
    void setErrorCallback(ErrorCallback callback) { error_callback_ = callback; }
    void setStatsCallback(StatsCallback callback) { stats_callback_ = callback; }

    // Statistics
    TransportStats getStats() const;
    void resetStats();

    // Configuration
    const UdpConfig& getConfig() const { return config_; }
    void updateConfig(const UdpConfig& config);

private:
    UdpConfig config_;
    std::atomic<bool> running_{false};
    
    // Socket
    int socket_fd_;
    struct sockaddr_in local_addr_;
    struct sockaddr_in remote_addr_;
    
    // Threads
    std::thread receive_thread_;
    std::thread stats_thread_;
    
    // Callbacks
    DataCallback data_callback_;
    AckCallback ack_callback_;
    ErrorCallback error_callback_;
    StatsCallback stats_callback_;
    
    // Statistics
    mutable std::mutex stats_mutex_;
    TransportStats stats_;
    
    // Packet processing
    void receiveLoop();
    void statsLoop();
    void processPacket(const uint8_t* buffer, size_t size, 
                      const struct sockaddr_in& from_addr);
    
    // Utility functions
    bool createSocket();
    bool bindSocket();
    bool setupSocketOptions();
    uint32_t calculateChecksum(const uint8_t* data, size_t size);
    uint32_t hashFileId(const std::string& file_id);
    uint64_t getCurrentTimestamp();
    
    // Packet creation
    std::vector<uint8_t> createPacket(PacketType type, const std::string& file_id,
                                     uint32_t chunk_id, const uint8_t* data = nullptr, 
                                     size_t data_size = 0);
    
    // Error handling
    void handleError(const std::string& error);
};

// Utility functions
std::string packetTypeToString(PacketType type);
bool validatePacket(const PacketHeader* header, size_t packet_size);
std::string formatBytes(uint64_t bytes);
std::string formatTime(double ms);

} // namespace transport
} // namespace transfer