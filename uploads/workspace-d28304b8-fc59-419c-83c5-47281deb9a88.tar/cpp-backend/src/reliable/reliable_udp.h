#pragma once
#include "udp_transport.h"
#include "manifest/manifest.h"
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <chrono>
#include <random>
#include <algorithm>

namespace transfer {
namespace reliable {

// Configuration for reliable transport
struct ReliableConfig {
    uint32_t window_size = 10;           // Sliding window size
    uint32_t max_retries = 5;             // Maximum retry attempts
    uint32_t timeout_ms = 1000;          // Initial timeout in milliseconds
    uint32_t max_timeout_ms = 10000;     // Maximum timeout
    double rtt_alpha = 0.125;             // RTT smoothing factor
    double rtt_beta = 0.25;               // RTT variance factor
    uint32_t duplicate_ack_threshold = 3; // Fast retransmit threshold
    bool enable_fast_retransmit = true;   // Enable fast retransmit
    bool enable_congestion_control = false; // Enable congestion control
};

// Sliding window entry
struct WindowEntry {
    uint32_t chunk_id;
    std::vector<uint8_t> data;
    std::chrono::steady_clock::time_point sent_time;
    uint32_t retry_count = 0;
    bool acked = false;
    uint32_t seq_num = 0;
};

// RTT measurement
struct RttMeasurement {
    double srtt = 0.0;    // Smoothed RTT
    double rttvar = 0.0;   // RTT variance
    double rto = 1.0;      // Retransmission timeout (seconds)
    
    void update(double measured_rtt) {
        if (srtt == 0.0) {
            // First measurement
            srtt = measured_rtt;
            rttvar = measured_rtt / 2.0;
        } else {
            // Update using RFC 6298 formulas
            rttvar = (1.0 - 0.25) * rttvar + 0.25 * std::abs(srtt - measured_rtt);
            srtt = (1.0 - 0.125) * srtt + 0.125 * measured_rtt;
        }
        
        rto = srtt + 4.0 * rttvar;
        rto = std::max(1.0, std::min(rto, 10.0)); // Clamp between 1s and 10s
    }
};

// Reliable transport statistics
struct ReliableStats {
    uint32_t packets_retransmitted = 0;
    uint32_t fast_retransmits = 0;
    uint32_t timeouts = 0;
    uint32_t duplicate_acks = 0;
    double average_rtt_ms = 0.0;
    double current_rto_ms = 0.0;
    uint32_t window_size = 0;
    double throughput_bps = 0.0;
    std::chrono::steady_clock::time_point start_time;
    std::chrono::steady_clock::time_point last_update;
};

class ReliableUdpSender {
public:
    ReliableUdpSender(const transport::UdpConfig& config, const ReliableConfig& reliable_config = {});
    ~ReliableUdpSender();

    // Connection management
    bool start();
    void stop();
    bool isRunning() const { return running_; }

    // File transfer
    bool sendFile(const std::string& filepath, const std::string& remote_ip, uint16_t remote_port);
    bool resumeTransfer(const std::string& file_id, const std::string& remote_ip, uint16_t remote_port);
    void cancelTransfer();

    // Configuration
    void updateConfig(const ReliableConfig& config) { reliable_config_ = config; }
    const ReliableConfig& getConfig() const { return reliable_config_; }

    // Statistics
    ReliableStats getStats() const;
    void resetStats();

    // Callbacks
    using ProgressCallback = std::function<void(double progress, uint32_t acked, uint32_t total)>;
    using CompletionCallback = std::function<void(bool success)>;
    using ErrorCallback = std::function<void(const std::string& error)>;

    void setProgressCallback(ProgressCallback callback) { progress_callback_ = callback; }
    void setCompletionCallback(CompletionCallback callback) { completion_callback_ = callback; }
    void setErrorCallback(ErrorCallback callback) { error_callback_ = callback; }

private:
    transport::UdpConfig transport_config_;
    ReliableConfig reliable_config_;
    std::unique_ptr<transport::UdpTransport> transport_;
    std::unique_ptr<manifest::ManifestManager> manifest_manager_;
    
    std::atomic<bool> running_{false};
    std::string current_file_id_;
    std::string current_remote_ip_;
    uint16_t current_remote_port_;
    
    // Sliding window
    uint32_t send_base_ = 0;              // Base of send window
    uint32_t next_seq_num_ = 0;           // Next sequence number
    std::unordered_map<uint32_t, WindowEntry> send_window_; // Active packets
    std::queue<uint32_t> pending_chunks_;  // Chunks waiting to be sent
    
    // RTT measurement
    RttMeasurement rtt_;
    std::unordered_map<uint32_t, std::chrono::steady_clock::time_point> packet_times_;
    
    // Duplicate ACK tracking
    std::unordered_map<uint32_t, uint32_t> duplicate_ack_counts_;
    
    // Statistics
    mutable std::mutex stats_mutex_;
    ReliableStats stats_;
    
    // Threads
    std::thread sender_thread_;
    std::thread timeout_thread_;
    
    // Callbacks
    ProgressCallback progress_callback_;
    CompletionCallback completion_callback_;
    ErrorCallback error_callback_;
    
    // Internal methods
    bool initializeTransfer(const std::string& filepath, const std::string& remote_ip, uint16_t remote_port);
    void senderLoop();
    void timeoutLoop();
    void sendNextChunk();
    void retransmitChunk(uint32_t chunk_id);
    void handleAck(const transport::AckPacket* ack);
    void handleTimeout(uint32_t chunk_id);
    void updateWindow();
    void updateProgress();
    void completeTransfer(bool success);
    void handleError(const std::string& error);
    
    // Utility methods
    uint32_t calculateTimeout() const;
    bool isWindowFull() const;
    void sendChunk(uint32_t chunk_id);
    void sendAckForChunk(uint32_t chunk_id);
};

class ReliableUdpReceiver {
public:
    ReliableUdpReceiver(const transport::UdpConfig& config, const ReliableConfig& reliable_config = {});
    ~ReliableUdpReceiver();

    // Connection management
    bool start(const std::string& output_dir = "./received");
    void stop();
    bool isRunning() const { return running_; }

    // Statistics
    ReliableStats getStats() const;
    void resetStats();

    // Callbacks
    using FileReceivedCallback = std::function<void(const std::string& filename, bool success)>;
    using ProgressCallback = std::function<void(const std::string& filename, double progress)>;

    void setFileReceivedCallback(FileReceivedCallback callback) { file_received_callback_ = callback; }
    void setProgressCallback(ProgressCallback callback) { progress_callback_ = callback; }

private:
    transport::UdpConfig transport_config_;
    ReliableConfig reliable_config_;
    std::unique_ptr<transport::UdpTransport> transport_;
    std::string output_dir_;
    
    std::atomic<bool> running_{false};
    
    // Receive buffer
    struct ReceiveSession {
        std::string file_id;
        std::string filename;
        std::string filepath;
        uint64_t file_size;
        uint32_t chunk_size;
        uint32_t total_chunks;
        uint32_t expected_seq_num = 0;
        std::unordered_map<uint32_t, std::vector<uint8_t>> receive_buffer_;
        std::unordered_set<uint32_t> received_chunks_;
        std::chrono::steady_clock::time_point start_time;
    };
    
    std::unordered_map<std::string, ReceiveSession> sessions_;
    
    // Statistics
    mutable std::mutex stats_mutex_;
    ReliableStats stats_;
    
    // Callbacks
    FileReceivedCallback file_received_callback_;
    ProgressCallback progress_callback_;
    
    // Internal methods
    void handleDataPacket(const transport::DataPacket* packet, size_t size);
    void handleHandshake(const transport::HandshakePacket* packet);
    void sendAck(const std::string& file_id, uint32_t chunk_id, uint32_t window_size = 0);
    void completeFile(const std::string& file_id);
    void cleanupSession(const std::string& file_id);
    void updateProgress(const std::string& file_id);
};

} // namespace reliable
} // namespace transfer