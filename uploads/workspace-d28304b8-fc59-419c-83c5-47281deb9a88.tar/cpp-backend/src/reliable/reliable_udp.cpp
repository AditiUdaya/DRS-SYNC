#include "reliable_udp.h"
#include <fstream>
#include <filesystem>
#include <iostream>
#include <algorithm>
#include <thread>

namespace transfer {
namespace reliable {

// ReliableUdpSender Implementation
ReliableUdpSender::ReliableUdpSender(const transport::UdpConfig& config, const ReliableConfig& reliable_config)
    : transport_config_(config), reliable_config_(reliable_config) {
    manifest_manager_ = std::make_unique<manifest::ManifestManager>("./manifests");
    stats_.start_time = std::chrono::steady_clock::now();
    stats_.last_update = stats_.start_time;
}

ReliableUdpSender::~ReliableUdpSender() {
    stop();
}

bool ReliableUdpSender::start() {
    if (running_.load()) {
        return true;
    }

    transport_ = std::make_unique<transport::UdpTransport>(transport_config_);
    
    // Setup callbacks
    transport_->setAckCallback([this](const transport::AckPacket* ack) {
        handleAck(ack);
    });
    
    transport_->setErrorCallback([this](const std::string& error) {
        handleError("Transport error: " + error);
    });

    if (!transport_->start()) {
        handleError("Failed to start transport");
        return false;
    }

    running_.store(true);
    
    // Start worker threads
    sender_thread_ = std::thread(&ReliableUdpSender::senderLoop, this);
    timeout_thread_ = std::thread(&ReliableUdpSender::timeoutLoop, this);

    std::cout << "🚀 Reliable UDP sender started" << std::endl;
    return true;
}

void ReliableUdpSender::stop() {
    if (!running_.load()) {
        return;
    }

    std::cout << "🛑 Stopping reliable UDP sender..." << std::endl;
    running_.store(false);

    if (transport_) {
        transport_->stop();
    }

    // Join threads
    if (sender_thread_.joinable()) {
        sender_thread_.join();
    }
    if (timeout_thread_.joinable()) {
        timeout_thread_.join();
    }

    std::cout << "✅ Reliable UDP sender stopped" << std::endl;
}

bool ReliableUdpSender::sendFile(const std::string& filepath, const std::string& remote_ip, uint16_t remote_port) {
    if (!initializeTransfer(filepath, remote_ip, remote_port)) {
        return false;
    }

    std::cout << "📤 Starting reliable file transfer: " << filepath << std::endl;
    return true;
}

bool ReliableUdpSender::resumeTransfer(const std::string& file_id, const std::string& remote_ip, uint16_t remote_port) {
    auto manifest_opt = manifest_manager_->loadManifest(file_id);
    if (!manifest_opt) {
        handleError("Manifest not found: " + file_id);
        return false;
    }

    current_file_id_ = file_id;
    current_remote_ip_ = remote_ip;
    current_remote_port_ = remote_port;

    // Update transport config
    transport_config_.remote_ip = remote_ip;
    transport_config_.remote_port = remote_port;
    transport_->updateConfig(transport_config_);

    // Load pending chunks
    auto pending = manifest_manager_->getPendingChunks(file_id);
    auto failed = manifest_manager_->getFailedChunks(file_id);
    
    // Combine pending and failed chunks
    std::unordered_set<uint32_t> chunks_to_send(pending.begin(), pending.end());
    chunks_to_send.insert(failed.begin(), failed.end());

    // Clear and populate pending queue
    while (!pending_chunks_.empty()) {
        pending_chunks_.pop();
    }
    
    for (uint32_t chunk_id : chunks_to_send) {
        pending_chunks_.push(chunk_id);
    }

    // Reset sliding window
    send_window_.clear();
    send_base_ = 0;
    next_seq_num_ = 0;

    std::cout << "🔄 Resuming transfer for file ID: " << file_id 
              << " (" << pending_chunks_.size() << " chunks pending)" << std::endl;
    
    return true;
}

void ReliableUdpSender::cancelTransfer() {
    std::cout << "❌ Cancelling transfer" << std::endl;
    completeTransfer(false);
}

ReliableStats ReliableUdpSender::getStats() const {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    ReliableStats stats = stats_;
    stats.window_size = send_window_.size();
    stats.current_rto_ms = rtt_.rto * 1000.0;
    stats.average_rtt_ms = rtt_.srtt * 1000.0;
    return stats;
}

void ReliableUdpSender::resetStats() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    stats_ = ReliableStats{};
    stats_.start_time = std::chrono::steady_clock::now();
    stats_.last_update = stats_.start_time;
}

bool ReliableUdpSender::initializeTransfer(const std::string& filepath, const std::string& remote_ip, uint16_t remote_port) {
    // Create manifest
    std::string file_id;
    try {
        file_id = manifest_manager_->createManifest(filepath, 4096);
    } catch (const std::exception& e) {
        handleError("Failed to create manifest: " + std::string(e.what()));
        return false;
    }

    current_file_id_ = file_id;
    current_remote_ip_ = remote_ip;
    current_remote_port_ = remote_port;

    // Update transport config
    transport_config_.remote_ip = remote_ip;
    transport_config_.remote_port = remote_port;
    transport_->updateConfig(transport_config_);

    // Load manifest and prepare chunks
    auto manifest_opt = manifest_manager_->loadManifest(file_id);
    if (!manifest_opt) {
        handleError("Failed to load manifest");
        return false;
    }

    const auto& manifest = *manifest_opt;
    
    // Clear pending queue and populate with all chunks
    while (!pending_chunks_.empty()) {
        pending_chunks_.pop();
    }
    
    for (uint32_t i = 0; i < manifest.total_chunks; ++i) {
        pending_chunks_.push(i);
    }

    // Reset sliding window
    send_window_.clear();
    send_base_ = 0;
    next_seq_num_ = 0;

    // Send handshake
    std::string filename = std::filesystem::path(filepath).filename().string();
    if (!transport_->sendHandshake(file_id, filename, manifest.total_size, 
                                  manifest.chunk_size, manifest.total_chunks)) {
        handleError("Failed to send handshake");
        return false;
    }

    std::cout << "📊 Transfer initialized:" << std::endl;
    std::cout << "  File ID: " << file_id << std::endl;
    std::cout << "  File: " << filename << std::endl;
    std::cout << "  Size: " << transport::formatBytes(manifest.total_size) << std::endl;
    std::cout << "  Chunks: " << manifest.total_chunks << std::endl;
    std::cout << "  Window size: " << reliable_config_.window_size << std::endl;

    return true;
}

void ReliableUdpSender::senderLoop() {
    while (running_.load()) {
        if (!pending_chunks_.empty() && !isWindowFull()) {
            sendNextChunk();
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void ReliableUdpSender::timeoutLoop() {
    while (running_.load()) {
        auto now = std::chrono::steady_clock::now();
        
        for (auto& [chunk_id, entry] : send_window_) {
            if (!entry.acked) {
                auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                    now - entry.sent_time).count();
                
                uint32_t timeout_ms = calculateTimeout();
                if (elapsed > timeout_ms) {
                    handleTimeout(chunk_id);
                }
            }
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void ReliableUdpSender::sendNextChunk() {
    if (pending_chunks_.empty() || isWindowFull()) {
        return;
    }

    uint32_t chunk_id = pending_chunks_.front();
    pending_chunks_.pop();
    
    sendChunk(chunk_id);
}

void ReliableUdpSender::sendChunk(uint32_t chunk_id) {
    auto manifest_opt = manifest_manager_->loadManifest(current_file_id_);
    if (!manifest_opt) {
        handleError("Failed to load manifest");
        return;
    }

    const auto& manifest = *manifest_opt;
    if (chunk_id >= manifest.chunks.size()) {
        handleError("Invalid chunk ID: " + std::to_string(chunk_id));
        return;
    }

    const auto& chunk_info = manifest.chunks[chunk_id];
    
    // Read chunk data
    std::ifstream file(manifest.filepath, std::ios::binary);
    if (!file.is_open()) {
        handleError("Failed to open file: " + manifest.filepath);
        return;
    }

    std::vector<uint8_t> data(chunk_info.size);
    file.seekg(chunk_info.offset);
    file.read(reinterpret_cast<char*>(data.data()), chunk_info.size);
    
    if (file.gcount() != chunk_info.size) {
        handleError("Failed to read chunk " + std::to_string(chunk_id));
        return;
    }

    // Create window entry
    WindowEntry entry;
    entry.chunk_id = chunk_id;
    entry.data = std::move(data);
    entry.sent_time = std::chrono::steady_clock::now();
    entry.seq_num = next_seq_num_++;
    
    send_window_[chunk_id] = entry;
    
    // Send packet
    if (!transport_->sendData(current_file_id_, chunk_id, entry.data.data(), entry.data.size())) {
        handleError("Failed to send chunk " + std::to_string(chunk_id));
        send_window_.erase(chunk_id);
        pending_chunks_.push(chunk_id); // Re-queue
        return;
    }

    // Record send time for RTT measurement
    packet_times_[chunk_id] = entry.sent_time;
    
    // Mark as sent in manifest
    manifest_manager_->markChunkSent(current_file_id_, chunk_id);
    
    std::cout << "📦 Sent chunk " << chunk_id << " (seq=" << entry.seq_num 
              << ", size=" << transport::formatBytes(entry.data.size()) << ")" << std::endl;
    
    updateProgress();
}

void ReliableUdpSender::retransmitChunk(uint32_t chunk_id) {
    auto it = send_window_.find(chunk_id);
    if (it == send_window_.end()) {
        return;
    }

    auto& entry = it->second;
    entry.retry_count++;
    entry.sent_time = std::chrono::steady_clock::now();
    
    if (entry.retry_count > reliable_config_.max_retries) {
        handleError("Max retries exceeded for chunk " + std::to_string(chunk_id));
        manifest_manager_->markChunkFailed(current_file_id_, chunk_id);
        send_window_.erase(it);
        return;
    }

    // Retransmit packet
    if (!transport_->sendData(current_file_id_, chunk_id, entry.data.data(), entry.data.size())) {
        handleError("Failed to retransmit chunk " + std::to_string(chunk_id));
        return;
    }

    // Update statistics
    {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.packets_retransmitted++;
    }

    std::cout << "🔄 Retransmitted chunk " << chunk_id 
              << " (attempt " << entry.retry_count << ")" << std::endl;
}

void ReliableUdpSender::handleAck(const transport::AckPacket* ack) {
    auto it = send_window_.find(ack->chunk_id);
    if (it == send_window_.end()) {
        // Duplicate ACK
        duplicate_ack_counts_[ack->chunk_id]++;
        
        {
            std::lock_guard<std::mutex> lock(stats_mutex_);
            stats_.duplicate_acks++;
        }
        
        // Fast retransmit
        if (reliable_config_.enable_fast_retransmit && 
            duplicate_ack_counts_[ack->chunk_id] >= reliable_config_.duplicate_ack_threshold) {
            
            std::cout << "⚡ Fast retransmit triggered for chunk " << ack->chunk_id << std::endl;
            retransmitChunk(ack->chunk_id);
            duplicate_ack_counts_[ack->chunk_id] = 0;
            
            {
                std::lock_guard<std::mutex> lock(stats_mutex_);
                stats_.fast_retransmits++;
            }
        }
        return;
    }

    auto& entry = it->second;
    if (entry.acked) {
        return; // Already acked
    }

    // Mark as acked
    entry.acked = true;
    
    // Measure RTT
    auto packet_time_it = packet_times_.find(ack->chunk_id);
    if (packet_time_it != packet_times_.end()) {
        auto now = std::chrono::steady_clock::now();
        auto rtt_ms = std::chrono::duration_cast<std::chrono::microseconds>(
            now - packet_time_it->second).count() / 1000.0;
        
        rtt_.update(rtt_ms / 1000.0); // Convert to seconds
        packet_times_.erase(packet_time_it);
    }

    // Update manifest
    manifest_manager_->markChunkAcked(current_file_id_, ack->chunk_id);
    
    // Clean up duplicate ACK count
    duplicate_ack_counts_.erase(ack->chunk_id);
    
    std::cout << "✅ Received ACK for chunk " << ack->chunk_id 
              << " (RTT=" << (rtt_.srtt * 1000.0) << "ms)" << std::endl;
    
    // Update sliding window
    updateWindow();
    updateProgress();
}

void ReliableUdpSender::handleTimeout(uint32_t chunk_id) {
    auto it = send_window_.find(chunk_id);
    if (it == send_window_.end() || it->second.acked) {
        return;
    }

    std::cout << "⏰ Timeout for chunk " << chunk_id << std::endl;
    
    {
        std::lock_guard<std::mutex> lock(stats_mutex_);
        stats_.timeouts++;
    }
    
    retransmitChunk(chunk_id);
}

void ReliableUdpSender::updateWindow() {
    // Slide window forward
    while (!send_window_.empty()) {
        auto it = send_window_.find(send_base_);
        if (it != send_window_.end() && it->second.acked) {
            send_window_.erase(it);
            send_base_++;
        } else {
            break;
        }
    }
}

void ReliableUdpSender::updateProgress() {
    auto manifest_opt = manifest_manager_->loadManifest(current_file_id_);
    if (!manifest_opt) {
        return;
    }

    const auto& manifest = *manifest_opt;
    double progress = manifest_manager_->getProgress(current_file_id_);
    
    if (progress_callback_) {
        progress_callback_(progress, manifest.chunks_acked, manifest.total_chunks);
    }

    // Check if transfer is complete
    if (progress >= 1.0) {
        completeTransfer(true);
    }
}

void ReliableUdpSender::completeTransfer(bool success) {
    std::cout << (success ? "✅" : "❌") << " Transfer " << (success ? "completed" : "failed") << std::endl;
    
    if (completion_callback_) {
        completion_callback_(success);
    }
    
    // Clean up
    send_window_.clear();
    while (!pending_chunks_.empty()) {
        pending_chunks_.pop();
    }
    packet_times_.clear();
    duplicate_ack_counts_.clear();
}

void ReliableUdpSender::handleError(const std::string& error) {
    std::cerr << "❌ Reliable UDP Sender Error: " << error << std::endl;
    
    if (error_callback_) {
        error_callback_(error);
    }
}

uint32_t ReliableUdpSender::calculateTimeout() const {
    return static_cast<uint32_t>(rtt_.rto * 1000.0); // Convert to milliseconds
}

bool ReliableUdpSender::isWindowFull() const {
    uint32_t unacked_count = 0;
    for (const auto& [chunk_id, entry] : send_window_) {
        if (!entry.acked) {
            unacked_count++;
        }
    }
    return unacked_count >= reliable_config_.window_size;
}

// ReliableUdpReceiver Implementation
ReliableUdpReceiver::ReliableUdpReceiver(const transport::UdpConfig& config, const ReliableConfig& reliable_config)
    : transport_config_(config), reliable_config_(reliable_config) {
    stats_.start_time = std::chrono::steady_clock::now();
    stats_.last_update = stats_.start_time;
}

ReliableUdpReceiver::~ReliableUdpReceiver() {
    stop();
}

bool ReliableUdpReceiver::start(const std::string& output_dir) {
    if (running_.load()) {
        return true;
    }

    output_dir_ = output_dir;
    std::filesystem::create_directories(output_dir_);

    transport_ = std::make_unique<transport::UdpTransport>(transport_config_);
    
    // Setup callbacks
    transport_->setDataCallback([this](const transport::DataPacket* packet, size_t size) {
        handleDataPacket(packet, size);
    });
    
    transport_->setErrorCallback([this](const std::string& error) {
        std::cerr << "❌ Transport error: " << error << std::endl;
    });

    if (!transport_->start()) {
        std::cerr << "❌ Failed to start transport" << std::endl;
        return false;
    }

    running_.store(true);
    std::cout << "🚀 Reliable UDP receiver started" << std::endl;
    std::cout << "📁 Output directory: " << output_dir_ << std::endl;
    
    return true;
}

void ReliableUdpReceiver::stop() {
    if (!running_.load()) {
        return;
    }

    std::cout << "🛑 Stopping reliable UDP receiver..." << std::endl;
    running_.store(false);

    if (transport_) {
        transport_->stop();
    }

    // Clean up all sessions
    for (auto& [file_id, session] : sessions_) {
        cleanupSession(file_id);
    }
    sessions_.clear();

    std::cout << "✅ Reliable UDP receiver stopped" << std::endl;
}

ReliableStats ReliableUdpReceiver::getStats() const {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    return stats_;
}

void ReliableUdpReceiver::resetStats() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    stats_ = ReliableStats{};
    stats_.start_time = std::chrono::steady_clock::now();
    stats_.last_update = stats_.start_time;
}

void ReliableUdpReceiver::handleDataPacket(const transport::DataPacket* packet, size_t size) {
    std::string file_id = std::to_string(packet->header.file_id_hash);
    
    std::cout << "📦 Received chunk " << packet->header.chunk_id 
              << " for file " << file_id 
              << " (" << transport::formatBytes(packet->header.size) << ")" << std::endl;

    auto it = sessions_.find(file_id);
    if (it == sessions_.end()) {
        std::cout << "⚠️  No session found for file " << file_id << std::endl;
        return;
    }

    auto& session = it->second;
    
    // Check if we already have this chunk
    if (session.received_chunks_.count(packet->header.chunk_id)) {
        std::cout << "🔄 Duplicate chunk " << packet->header.chunk_id << ", sending ACK" << std::endl;
        sendAck(file_id, packet->header.chunk_id);
        return;
    }

    // Store chunk data
    std::vector<uint8_t> chunk_data(packet->header.size);
    std::memcpy(chunk_data.data(), packet->data, packet->header.size);
    session.receive_buffer_[packet->header.chunk_id] = std::move(chunk_data);
    session.received_chunks_.insert(packet->header.chunk_id);

    // Send ACK
    sendAck(file_id, packet->header.chunk_id, reliable_config_.window_size);

    // Update progress
    updateProgress(file_id);

    // Check if file is complete
    if (session.received_chunks_.size() == session.total_chunks) {
        completeFile(file_id);
    }
}

void ReliableUdpReceiver::handleHandshake(const transport::HandshakePacket* packet) {
    std::string file_id = std::to_string(packet->header.file_id_hash);
    std::string filename(packet->filename);
    
    std::cout << "🤝 Received handshake for file: " << filename << std::endl;

    // Create session
    ReceiveSession session;
    session.file_id = file_id;
    session.filename = filename;
    session.filepath = output_dir_ + "/" + filename;
    session.file_size = packet->file_size;
    session.chunk_size = packet->chunk_size;
    session.total_chunks = packet->total_chunks;
    session.start_time = std::chrono::steady_clock::now();

    sessions_[file_id] = session;
    
    std::cout << "📊 Created session:" << std::endl;
    std::cout << "  File ID: " << file_id << std::endl;
    std::cout << "  Filename: " << filename << std::endl;
    std::cout << "  Size: " << transport::formatBytes(session.file_size) << std::endl;
    std::cout << "  Chunks: " << session.total_chunks << std::endl;
}

void ReliableUdpReceiver::sendAck(const std::string& file_id, uint32_t chunk_id, uint32_t window_size) {
    // In a real implementation, this would send an ACK packet
    // For now, we just log it
    std::cout << "✅ Sending ACK for chunk " << chunk_id << std::endl;
}

void ReliableUdpReceiver::completeFile(const std::string& file_id) {
    auto it = sessions_.find(file_id);
    if (it == sessions_.end()) {
        return;
    }

    auto& session = it->second;
    std::cout << "🎉 File transfer completed: " << session.filename << std::endl;

    // Reassemble file
    std::ofstream output_file(session.filepath, std::ios::binary);
    if (!output_file.is_open()) {
        std::cerr << "❌ Failed to create output file: " << session.filepath << std::endl;
        cleanupSession(file_id);
        return;
    }

    // Write chunks in order
    for (uint32_t i = 0; i < session.total_chunks; ++i) {
        auto chunk_it = session.receive_buffer_.find(i);
        if (chunk_it == session.receive_buffer_.end()) {
            std::cerr << "❌ Missing chunk " << i << std::endl;
            output_file.close();
            cleanupSession(file_id);
            return;
        }

        output_file.write(reinterpret_cast<const char*>(chunk_it->second.data()), chunk_it->second.size());
    }

    output_file.close();

    // Verify file size
    uint64_t received_size = std::filesystem::file_size(session.filepath);
    
    auto duration = std::chrono::steady_clock::now() - session.start_time;
    auto duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
    
    std::cout << "✅ File successfully received:" << std::endl;
    std::cout << "  Path: " << session.filepath << std::endl;
    std::cout << "  Size: " << transport::formatBytes(received_size) << std::endl;
    std::cout << "  Chunks: " << session.received_chunks_.size() << std::endl;
    std::cout << "  Duration: " << transport::formatTime(duration_ms) << std::endl;
    
    if (duration_ms > 0) {
        double throughput_bps = (received_size * 1000.0) / duration_ms;
        std::cout << "  Throughput: " << transport::formatBytes(static_cast<uint64_t>(throughput_bps)) << "/s" << std::endl;
    }

    // Call callback
    if (file_received_callback_) {
        file_received_callback_(session.filename, true);
    }

    cleanupSession(file_id);
}

void ReliableUdpReceiver::cleanupSession(const std::string& file_id) {
    sessions_.erase(file_id);
}

void ReliableUdpReceiver::updateProgress(const std::string& file_id) {
    auto it = sessions_.find(file_id);
    if (it == sessions_.end()) {
        return;
    }

    const auto& session = it->second;
    double progress = (session.received_chunks_.size() * 100.0) / session.total_chunks;
    
    std::cout << "📈 Progress: " << progress << "% (" 
              << session.received_chunks_.size() << "/" << session.total_chunks << " chunks)" << std::endl;

    if (progress_callback_) {
        progress_callback_(session.filename, progress / 100.0);
    }
}

} // namespace reliable
} // namespace transfer