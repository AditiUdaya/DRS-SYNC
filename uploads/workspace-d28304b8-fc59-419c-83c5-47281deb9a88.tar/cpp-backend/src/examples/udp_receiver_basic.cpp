#include "transport/udp_transport.h"
#include "manifest/manifest.h"
#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <unordered_map>
#include <filesystem>

using namespace transfer;

class BasicUdpReceiver {
public:
    BasicUdpReceiver(const std::string& local_ip, uint16_t local_port)
        : local_ip_(local_ip), local_port_(local_port) {}

    bool startReceiving(const std::string& output_dir = "./received") {
        output_dir_ = output_dir;
        std::filesystem::create_directories(output_dir_);

        // Setup UDP transport
        transport::UdpConfig config;
        config.local_ip = local_ip_;
        config.local_port = local_port_;
        config.remote_ip = "";  // Not needed for receiver
        config.remote_port = 0;

        transport::UdpTransport udp(config);
        
        // Setup callbacks
        udp.setDataCallback([&](const transport::DataPacket* packet, size_t size) {
            handleDataPacket(packet, size);
        });
        
        udp.setErrorCallback([&](const std::string& error) {
            std::cerr << "❌ Transport error: " << error << std::endl;
        });

        // Stats callback
        udp.setStatsCallback([&](const transport::TransportStats& stats) {
            last_stats_ = stats;
        });

        if (!udp.start()) {
            std::cerr << "❌ Failed to start UDP transport" << std::endl;
            return false;
        }

        std::cout << "🚀 UDP receiver started on " << local_ip_ << ":" << local_port_ << std::endl;
        std::cout << "📁 Output directory: " << output_dir_ << std::endl;

        // Run receiver loop
        running_ = true;
        receiver_loop_ = std::thread([&]() {
            runReceiverLoop(udp);
        });

        // Wait for user input to stop
        std::cout << "📡 Waiting for incoming files... (Press Enter to stop)" << std::endl;
        std::cin.get();

        running_ = false;
        if (receiver_loop_.joinable()) {
            receiver_loop_.join();
        }

        udp.stop();
        return true;
    }

private:
    std::string local_ip_;
    uint16_t local_port_;
    std::string output_dir_;
    std::atomic<bool> running_{false};
    std::thread receiver_loop_;
    transport::TransportStats last_stats_;
    
    struct FileSession {
        std::string file_id;
        std::string filename;
        std::string filepath;
        uint64_t file_size;
        uint32_t chunk_size;
        uint32_t total_chunks;
        std::unordered_map<uint32_t, std::vector<uint8_t>> received_chunks;
        uint32_t chunks_received = 0;
        std::chrono::steady_clock::time_point start_time;
    };

    std::unordered_map<std::string, FileSession> sessions_;

    void handleDataPacket(const transport::DataPacket* packet, size_t size) {
        std::string file_id = std::to_string(packet->header.file_id_hash);
        
        std::cout << "📦 Received chunk " << packet->header.chunk_id 
                  << " for file " << file_id 
                  << " (" << transport::formatBytes(packet->header.size) << ")" << std::endl;

        // Find or create session
        auto it = sessions_.find(file_id);
        if (it == sessions_.end()) {
            std::cout << "⚠️  No session found for file " << file_id << std::endl;
            return;
        }

        auto& session = it->second;
        
        // Store chunk data
        std::vector<uint8_t> chunk_data(packet->header.size);
        std::memcpy(chunk_data.data(), packet->data, packet->header.size);
        session.received_chunks[packet->header.chunk_id] = std::move(chunk_data);
        session.chunks_received++;

        // Send ACK
        sendAck(file_id, packet->header.chunk_id);

        // Check if file is complete
        if (session.chunks_received == session.total_chunks) {
            completeFile(session);
            sessions_.erase(it);
        }

        // Print progress
        double progress = (session.chunks_received * 100.0) / session.total_chunks;
        std::cout << "📈 Progress: " << progress << "% (" 
                  << session.chunks_received << "/" << session.total_chunks << " chunks)" << std::endl;
    }

    void sendAck(const std::string& file_id, uint32_t chunk_id) {
        // In a real implementation, this would send an ACK packet
        // For this basic example, we just log it
        std::cout << "✅ Would send ACK for chunk " << chunk_id << std::endl;
    }

    void completeFile(const FileSession& session) {
        std::cout << "🎉 File transfer completed: " << session.filename << std::endl;

        // Reassemble file
        std::ofstream output_file(session.filepath, std::ios::binary);
        if (!output_file.is_open()) {
            std::cerr << "❌ Failed to create output file: " << session.filepath << std::endl;
            return;
        }

        // Write chunks in order
        for (uint32_t i = 0; i < session.total_chunks; ++i) {
            auto it = session.received_chunks.find(i);
            if (it == session.received_chunks.end()) {
                std::cerr << "❌ Missing chunk " << i << std::endl;
                return;
            }

            output_file.write(reinterpret_cast<const char*>(it->second.data()), it->second.size());
        }

        output_file.close();

        // Verify file size
        std::filesystem::path p(session.filepath);
        uint64_t received_size = std::filesystem::file_size(p);
        
        auto duration = std::chrono::steady_clock::now() - session.start_time;
        auto duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
        
        std::cout << "✅ File successfully received:" << std::endl;
        std::cout << "  Path: " << session.filepath << std::endl;
        std::cout << "  Size: " << transport::formatBytes(received_size) << std::endl;
        std::cout << "  Chunks: " << session.chunks_received << std::endl;
        std::cout << "  Duration: " << transport::formatTime(duration_ms) << std::endl;
        
        if (duration_ms > 0) {
            double throughput_bps = (received_size * 1000.0) / duration_ms;
            std::cout << "  Throughput: " << transport::formatBytes(static_cast<uint64_t>(throughput_bps)) << "/s" << std::endl;
        }
    }

    void runReceiverLoop(transport::UdpTransport& udp) {
        auto last_stats_time = std::chrono::steady_clock::now();
        
        while (running_) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            
            // Print stats every 5 seconds
            auto now = std::chrono::steady_clock::now();
            if (now - last_stats_time > std::chrono::seconds(5)) {
                printStats();
                last_stats_time = now;
            }
        }
    }

    void printStats() {
        if (sessions_.empty()) {
            return;
        }

        std::cout << "\n📊 Active Sessions:" << std::endl;
        for (const auto& [file_id, session] : sessions_) {
            double progress = (session.chunks_received * 100.0) / session.total_chunks;
            std::cout << "  " << session.filename << ": " << progress << "% (" 
                      << session.chunks_received << "/" << session.total_chunks << " chunks)" << std::endl;
        }

        if (last_stats_.packets_received > 0) {
            std::cout << "📈 Network Stats:" << std::endl;
            std::cout << "  Packets received: " << last_stats_.packets_received << std::endl;
            std::cout << "  Bytes received: " << transport::formatBytes(last_stats_.bytes_received) << std::endl;
            std::cout << "  Throughput: " << transport::formatBytes(static_cast<uint64_t>(last_stats_.throughput_bps)) << "/s" << std::endl;
        }
        std::cout << std::endl;
    }
};

int main(int argc, char* argv[]) {
    std::string local_ip = "0.0.0.0";
    uint16_t local_port = 8080;
    std::string output_dir = "./received";

    if (argc >= 2) {
        local_port = static_cast<uint16_t>(std::stoi(argv[1]));
    }
    if (argc >= 3) {
        output_dir = argv[2];
    }

    std::cout << "🎯 UDP File Receiver" << std::endl;
    std::cout << "Usage: " << argv[0] << " [port] [output_dir]" << std::endl;
    std::cout << "Starting with: " << local_ip << ":" << local_port << " -> " << output_dir << std::endl;

    BasicUdpReceiver receiver(local_ip, local_port);
    bool success = receiver.startReceiving(output_dir);

    return success ? 0 : 1;
}