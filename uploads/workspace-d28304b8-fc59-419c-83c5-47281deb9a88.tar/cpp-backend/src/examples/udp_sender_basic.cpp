#include "transport/udp_transport.h"
#include "manifest/manifest.h"
#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <atomic>

using namespace transfer;

class BasicUdpSender {
public:
    BasicUdpSender(const std::string& remote_ip, uint16_t remote_port)
        : remote_ip_(remote_ip), remote_port_(remote_port) {}

    bool sendFile(const std::string& filepath) {
        std::cout << "📤 Starting to send file: " << filepath << std::endl;

        // Create manifest
        manifest::ManifestManager manager("./manifests");
        std::string file_id;
        
        try {
            file_id = manager.createManifest(filepath, 4096);
        } catch (const std::exception& e) {
            std::cerr << "❌ Failed to create manifest: " << e.what() << std::endl;
            return false;
        }

        std::cout << "✅ Created manifest with ID: " << file_id << std::endl;

        // Load file
        std::ifstream file(filepath, std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "❌ Cannot open file: " << filepath << std::endl;
            return false;
        }

        // Get file info
        file.seekg(0, std::ios::end);
        uint64_t file_size = file.tellg();
        file.seekg(0, std::ios::beg);

        auto manifest_opt = manager.loadManifest(file_id);
        if (!manifest_opt) {
            std::cerr << "❌ Failed to load manifest" << std::endl;
            return false;
        }

        const auto& manifest = *manifest_opt;
        std::cout << "📊 File info:" << std::endl;
        std::cout << "  Size: " << transport::formatBytes(file_size) << std::endl;
        std::cout << "  Chunks: " << manifest.total_chunks << std::endl;
        std::cout << "  Chunk size: " << transport::formatBytes(manifest.chunk_size) << std::endl;

        // Setup UDP transport
        transport::UdpConfig config;
        config.local_port = 0;  // Let OS choose
        config.remote_ip = remote_ip_;
        config.remote_port = remote_port_;
        config.mtu = 1400;

        transport::UdpTransport udp(config);
        
        // Setup callbacks
        std::atomic<bool> handshake_received{false};
        std::atomic<uint32_t> acked_chunks{0};
        
        udp.setAckCallback([&](const transport::AckPacket* ack) {
            std::cout << "✅ Received ACK for chunk " << ack->chunk_id << std::endl;
            manager.markChunkAcked(file_id, ack->chunk_id);
            acked_chunks++;
            
            double progress = (acked_chunks * 100.0) / manifest.total_chunks;
            std::cout << "📈 Progress: " << progress << "%" << std::endl;
        });
        
        udp.setErrorCallback([&](const std::string& error) {
            std::cerr << "❌ Transport error: " << error << std::endl;
        });

        if (!udp.start()) {
            std::cerr << "❌ Failed to start UDP transport" << std::endl;
            return false;
        }

        std::cout << "🚀 UDP transport started" << std::endl;

        // Send handshake
        std::string filename = std::filesystem::path(filepath).filename().string();
        if (!udp.sendHandshake(file_id, filename, file_size, manifest.chunk_size, manifest.total_chunks)) {
            std::cerr << "❌ Failed to send handshake" << std::endl;
            udp.stop();
            return false;
        }

        std::cout << "🤝 Handshake sent, waiting for receiver..." << std::endl;
        
        // Wait a bit for handshake to be processed
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));

        // Send chunks
        std::vector<uint8_t> buffer(manifest.chunk_size);
        uint32_t chunks_sent = 0;
        
        for (const auto& chunk : manifest.chunks) {
            if (chunk.status != manifest::ChunkStatus::PENDING) {
                continue;
            }

            // Read chunk data
            file.seekg(chunk.offset);
            file.read(reinterpret_cast<char*>(buffer.data()), chunk.size);
            
            if (file.gcount() != chunk.size) {
                std::cerr << "❌ Failed to read chunk " << chunk.id << std::endl;
                continue;
            }

            // Send chunk
            if (!udp.sendData(file_id, chunk.id, buffer.data(), chunk.size)) {
                std::cerr << "❌ Failed to send chunk " << chunk.id << std::endl;
                continue;
            }

            manager.markChunkSent(file_id, chunk.id);
            chunks_sent++;

            std::cout << "📦 Sent chunk " << chunk.id << " (" 
                      << transport::formatBytes(chunk.size) << ")" << std::endl;

            // Small delay between chunks to avoid overwhelming the receiver
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }

        std::cout << "📊 Sent " << chunks_sent << " chunks" << std::endl;

        // Wait for all ACKs (with timeout)
        std::cout << "⏳ Waiting for ACKs..." << std::endl;
        auto start_time = std::chrono::steady_clock::now();
        auto timeout = std::chrono::seconds(30);
        
        while (acked_chunks < chunks_sent) {
            if (std::chrono::steady_clock::now() - start_time > timeout) {
                std::cout << "⏰ Timeout waiting for ACKs" << std::endl;
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        // Print final statistics
        auto stats = udp.getStats();
        std::cout << "\n📊 Transfer Statistics:" << std::endl;
        std::cout << "  Packets sent: " << stats.packets_sent << std::endl;
        std::cout << "  Packets received: " << stats.packets_received << std::endl;
        std::cout << "  Bytes sent: " << transport::formatBytes(stats.bytes_sent) << std::endl;
        std::cout << "  Throughput: " << transport::formatBytes(static_cast<uint64_t>(stats.throughput_bps)) << "/s" << std::endl;
        std::cout << "  Loss rate: " << (stats.loss_rate * 100.0) << "%" << std::endl;
        std::cout << "  Chunks ACKed: " << acked_chunks << "/" << chunks_sent << std::endl;

        udp.stop();
        
        bool success = (acked_chunks == chunks_sent);
        if (success) {
            std::cout << "✅ File transfer completed successfully!" << std::endl;
        } else {
            std::cout << "⚠️  File transfer completed with some chunks not ACKed" << std::endl;
        }

        return success;
    }

private:
    std::string remote_ip_;
    uint16_t remote_port_;
};

int main(int argc, char* argv[]) {
    if (argc != 4) {
        std::cout << "Usage: " << argv[0] << " <file_path> <remote_ip> <remote_port>" << std::endl;
        std::cout << "Example: " << argv[0] << " test.txt 127.0.0.1 8080" << std::endl;
        return 1;
    }

    std::string filepath = argv[1];
    std::string remote_ip = argv[2];
    uint16_t remote_port = static_cast<uint16_t>(std::stoi(argv[3]));

    if (!std::filesystem::exists(filepath)) {
        std::cerr << "❌ File not found: " << filepath << std::endl;
        return 1;
    }

    BasicUdpSender sender(remote_ip, remote_port);
    bool success = sender.sendFile(filepath);

    return success ? 0 : 1;
}