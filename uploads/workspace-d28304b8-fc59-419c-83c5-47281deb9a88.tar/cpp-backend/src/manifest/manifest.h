#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <chrono>
#include <optional>
#include <nlohmann/json.hpp>

namespace transfer {
namespace manifest {

enum class ChunkStatus {
    PENDING,
    SENT,
    ACKED,
    FAILED
};

enum class TransferMode {
    FILE,
    STREAM,
    COMPRESSED,
    ENCRYPTED,
    PQC_ENCRYPTED
};

struct ChunkInfo {
    uint32_t id;
    uint64_t offset;
    uint32_t size;
    uint32_t compressed_size = 0;
    std::string hash;
    ChunkStatus status = ChunkStatus::PENDING;
    std::chrono::steady_clock::time_point last_sent;
    uint32_t retry_count = 0;
    std::string nonce;  // For encryption
    std::string auth_tag;  // For encryption
};

struct FileManifest {
    std::string file_id;
    std::string filename;
    std::string filepath;
    uint64_t total_size;
    uint32_t chunk_size;
    uint32_t total_chunks;
    std::string file_hash;
    TransferMode mode = TransferMode::FILE;
    bool compressed = false;
    bool encrypted = false;
    std::chrono::steady_clock::time_point created_at;
    std::chrono::steady_clock::time_point updated_at;
    std::vector<ChunkInfo> chunks;
    
    // Statistics
    uint32_t chunks_sent = 0;
    uint32_t chunks_acked = 0;
    uint32_t chunks_failed = 0;
    double progress = 0.0;
    
    // Network metrics
    double rtt_ms = 0.0;
    double loss_rate = 0.0;
    uint32_t window_size = 10;
    double throughput_bps = 0.0;
};

class ManifestManager {
public:
    ManifestManager(const std::string& manifest_dir = "./manifests");
    ~ManifestManager() = default;

    // Manifest creation and loading
    std::string createManifest(const std::string& filepath, uint32_t chunk_size = 65536);
    std::optional<FileManifest> loadManifest(const std::string& file_id);
    bool saveManifest(const FileManifest& manifest);
    bool deleteManifest(const std::string& file_id);
    
    // Chunk operations
    bool markChunkSent(const std::string& file_id, uint32_t chunk_id);
    bool markChunkAcked(const std::string& file_id, uint32_t chunk_id);
    bool markChunkFailed(const std::string& file_id, uint32_t chunk_id);
    
    // Progress tracking
    double getProgress(const std::string& file_id);
    std::vector<uint32_t> getPendingChunks(const std::string& file_id);
    std::vector<uint32_t> getSentChunks(const std::string& file_id);
    std::vector<uint32_t> getFailedChunks(const std::string& file_id);
    
    // Statistics
    void updateStatistics(const std::string& file_id);
    FileManifest::Statistics getStatistics(const std::string& file_id);
    
    // List operations
    std::vector<std::string> listManifests();
    bool manifestExists(const std::string& file_id);
    
    // Cleanup
    void cleanupOldManifests(int max_age_hours = 24);

private:
    std::string manifest_dir_;
    std::unordered_map<std::string, FileManifest> cache_;
    
    std::string generateFileId();
    std::string getManifestPath(const std::string& file_id);
    void updateProgress(FileManifest& manifest);
    ChunkInfo& getChunkInfo(FileManifest& manifest, uint32_t chunk_id);
    
    // JSON serialization
    nlohmann::json serializeChunk(const ChunkInfo& chunk);
    ChunkInfo deserializeChunk(const nlohmann::json& j);
    nlohmann::json serializeManifest(const FileManifest& manifest);
    FileManifest deserializeManifest(const nlohmann::json& j);
};

} // namespace manifest
} // namespace transfer