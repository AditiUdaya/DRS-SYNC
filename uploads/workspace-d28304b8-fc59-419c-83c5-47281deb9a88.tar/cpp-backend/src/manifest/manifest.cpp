#include "manifest.h"
#include <fstream>
#include <filesystem>
#include <random>
#include <iomanip>
#include <sstream>
#include <algorithm>

namespace transfer {
namespace manifest {

ManifestManager::ManifestManager(const std::string& manifest_dir) 
    : manifest_dir_(manifest_dir) {
    std::filesystem::create_directories(manifest_dir_);
}

std::string ManifestManager::createManifest(const std::string& filepath, uint32_t chunk_size) {
    auto file_id = generateFileId();
    FileManifest manifest;
    
    manifest.file_id = file_id;
    manifest.filename = std::filesystem::path(filepath).filename().string();
    manifest.filepath = filepath;
    manifest.chunk_size = chunk_size;
    manifest.created_at = std::chrono::steady_clock::now();
    manifest.updated_at = manifest.created_at;
    
    // Get file size
    std::ifstream file(filepath, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open file: " + filepath);
    }
    
    manifest.total_size = file.tellg();
    manifest.total_chunks = (manifest.total_size + chunk_size - 1) / chunk_size;
    
    // Initialize chunks
    manifest.chunks.reserve(manifest.total_chunks);
    for (uint32_t i = 0; i < manifest.total_chunks; ++i) {
        ChunkInfo chunk;
        chunk.id = i;
        chunk.offset = i * chunk_size;
        chunk.size = std::min(chunk_size, static_cast<uint32_t>(manifest.total_size - chunk.offset));
        manifest.chunks.push_back(chunk);
    }
    
    // Save manifest
    if (!saveManifest(manifest)) {
        throw std::runtime_error("Failed to save manifest");
    }
    
    cache_[file_id] = manifest;
    return file_id;
}

std::optional<FileManifest> ManifestManager::loadManifest(const std::string& file_id) {
    // Check cache first
    auto it = cache_.find(file_id);
    if (it != cache_.end()) {
        return it->second;
    }
    
    // Load from disk
    std::string manifest_path = getManifestPath(file_id);
    std::ifstream file(manifest_path);
    if (!file.is_open()) {
        return std::nullopt;
    }
    
    try {
        nlohmann::json j;
        file >> j;
        auto manifest = deserializeManifest(j);
        cache_[file_id] = manifest;
        return manifest;
    } catch (const std::exception& e) {
        return std::nullopt;
    }
}

bool ManifestManager::saveManifest(const FileManifest& manifest) {
    std::string manifest_path = getManifestPath(manifest.file_id);
    std::ofstream file(manifest_path);
    if (!file.is_open()) {
        return false;
    }
    
    try {
        auto j = serializeManifest(manifest);
        file << j.dump(4);
        cache_[manifest.file_id] = manifest;
        return true;
    } catch (const std::exception& e) {
        return false;
    }
}

bool ManifestManager::deleteManifest(const std::string& file_id) {
    std::string manifest_path = getManifestPath(file_id);
    bool deleted = std::filesystem::remove(manifest_path);
    cache_.erase(file_id);
    return deleted;
}

bool ManifestManager::markChunkSent(const std::string& file_id, uint32_t chunk_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return false;
    }
    
    auto& manifest = *manifest_opt;
    auto& chunk = getChunkInfo(manifest, chunk_id);
    
    if (chunk.status == ChunkStatus::PENDING) {
        chunk.status = ChunkStatus::SENT;
        chunk.last_sent = std::chrono::steady_clock::now();
        manifest.updated_at = chunk.last_sent;
        updateProgress(manifest);
        return saveManifest(manifest);
    }
    
    return true;
}

bool ManifestManager::markChunkAcked(const std::string& file_id, uint32_t chunk_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return false;
    }
    
    auto& manifest = *manifest_opt;
    auto& chunk = getChunkInfo(manifest, chunk_id);
    
    if (chunk.status == ChunkStatus::SENT) {
        chunk.status = ChunkStatus::ACKED;
        manifest.updated_at = std::chrono::steady_clock::now();
        updateProgress(manifest);
        return saveManifest(manifest);
    }
    
    return true;
}

bool ManifestManager::markChunkFailed(const std::string& file_id, uint32_t chunk_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return false;
    }
    
    auto& manifest = *manifest_opt;
    auto& chunk = getChunkInfo(manifest, chunk_id);
    
    chunk.status = ChunkStatus::FAILED;
    chunk.retry_count++;
    manifest.updated_at = std::chrono::steady_clock::now();
    updateProgress(manifest);
    return saveManifest(manifest);
}

double ManifestManager::getProgress(const std::string& file_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return 0.0;
    }
    
    const auto& manifest = *manifest_opt;
    if (manifest.total_chunks == 0) {
        return 0.0;
    }
    
    uint32_t acked = 0;
    for (const auto& chunk : manifest.chunks) {
        if (chunk.status == ChunkStatus::ACKED) {
            acked++;
        }
    }
    
    return static_cast<double>(acked) / manifest.total_chunks;
}

std::vector<uint32_t> ManifestManager::getPendingChunks(const std::string& file_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return {};
    }
    
    std::vector<uint32_t> pending;
    for (const auto& chunk : manifest_opt->chunks) {
        if (chunk.status == ChunkStatus::PENDING) {
            pending.push_back(chunk.id);
        }
    }
    return pending;
}

std::vector<uint32_t> ManifestManager::getSentChunks(const std::string& file_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return {};
    }
    
    std::vector<uint32_t> sent;
    for (const auto& chunk : manifest_opt->chunks) {
        if (chunk.status == ChunkStatus::SENT) {
            sent.push_back(chunk.id);
        }
    }
    return sent;
}

std::vector<uint32_t> ManifestManager::getFailedChunks(const std::string& file_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return {};
    }
    
    std::vector<uint32_t> failed;
    for (const auto& chunk : manifest_opt->chunks) {
        if (chunk.status == ChunkStatus::FAILED) {
            failed.push_back(chunk.id);
        }
    }
    return failed;
}

void ManifestManager::updateStatistics(const std::string& file_id) {
    auto manifest_opt = loadManifest(file_id);
    if (!manifest_opt) {
        return;
    }
    
    auto& manifest = *manifest_opt;
    updateProgress(manifest);
    saveManifest(manifest);
}

std::vector<std::string> ManifestManager::listManifests() {
    std::vector<std::string> file_ids;
    
    for (const auto& entry : std::filesystem::directory_iterator(manifest_dir_)) {
        if (entry.path().extension() == ".json") {
            std::string filename = entry.path().filename().string();
            // Remove .json extension
            file_ids.push_back(filename.substr(0, filename.length() - 5));
        }
    }
    
    return file_ids;
}

bool ManifestManager::manifestExists(const std::string& file_id) {
    std::string manifest_path = getManifestPath(file_id);
    return std::filesystem::exists(manifest_path);
}

void ManifestManager::cleanupOldManifests(int max_age_hours) {
    auto now = std::chrono::steady_clock::now();
    auto max_age = std::chrono::hours(max_age_hours);
    
    for (const auto& file_id : listManifests()) {
        auto manifest_opt = loadManifest(file_id);
        if (manifest_opt) {
            auto age = now - manifest_opt->created_at;
            if (age > max_age) {
                deleteManifest(file_id);
            }
        }
    }
}

std::string ManifestManager::generateFileId() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 15);
    
    std::stringstream ss;
    ss << std::hex;
    for (int i = 0; i < 32; ++i) {
        ss << dis(gen);
    }
    
    return ss.str();
}

std::string ManifestManager::getManifestPath(const std::string& file_id) {
    return manifest_dir_ + "/" + file_id + ".json";
}

void ManifestManager::updateProgress(FileManifest& manifest) {
    uint32_t pending = 0, sent = 0, acked = 0, failed = 0;
    
    for (const auto& chunk : manifest.chunks) {
        switch (chunk.status) {
            case ChunkStatus::PENDING: pending++; break;
            case ChunkStatus::SENT: sent++; break;
            case ChunkStatus::ACKED: acked++; break;
            case ChunkStatus::FAILED: failed++; break;
        }
    }
    
    manifest.chunks_pending = pending;
    manifest.chunks_sent = sent;
    manifest.chunks_acked = acked;
    manifest.chunks_failed = failed;
    manifest.progress = manifest.total_chunks > 0 ? 
        static_cast<double>(acked) / manifest.total_chunks : 0.0;
}

ChunkInfo& ManifestManager::getChunkInfo(FileManifest& manifest, uint32_t chunk_id) {
    if (chunk_id >= manifest.chunks.size()) {
        throw std::out_of_range("Chunk ID out of range");
    }
    return manifest.chunks[chunk_id];
}

nlohmann::json ManifestManager::serializeChunk(const ChunkInfo& chunk) {
    nlohmann::json j;
    j["id"] = chunk.id;
    j["offset"] = chunk.offset;
    j["size"] = chunk.size;
    j["compressed_size"] = chunk.compressed_size;
    j["hash"] = chunk.hash;
    j["status"] = static_cast<int>(chunk.status);
    j["retry_count"] = chunk.retry_count;
    j["nonce"] = chunk.nonce;
    j["auth_tag"] = chunk.auth_tag;
    
    auto last_sent_time = chunk.last_sent.time_since_epoch().count();
    j["last_sent"] = last_sent_time;
    
    return j;
}

ChunkInfo ManifestManager::deserializeChunk(const nlohmann::json& j) {
    ChunkInfo chunk;
    chunk.id = j["id"];
    chunk.offset = j["offset"];
    chunk.size = j["size"];
    chunk.compressed_size = j.value("compressed_size", 0);
    chunk.hash = j.value("hash", "");
    chunk.status = static_cast<ChunkStatus>(j["status"]);
    chunk.retry_count = j.value("retry_count", 0);
    chunk.nonce = j.value("nonce", "");
    chunk.auth_tag = j.value("auth_tag", "");
    
    if (j.contains("last_sent")) {
        auto last_sent_time = j["last_sent"].get<std::chrono::steady_clock::duration::rep>();
        chunk.last_sent = std::chrono::steady_clock::time_point(
            std::chrono::steady_clock::duration(last_sent_time));
    }
    
    return chunk;
}

nlohmann::json ManifestManager::serializeManifest(const FileManifest& manifest) {
    nlohmann::json j;
    j["file_id"] = manifest.file_id;
    j["filename"] = manifest.filename;
    j["filepath"] = manifest.filepath;
    j["total_size"] = manifest.total_size;
    j["chunk_size"] = manifest.chunk_size;
    j["total_chunks"] = manifest.total_chunks;
    j["file_hash"] = manifest.file_hash;
    j["mode"] = static_cast<int>(manifest.mode);
    j["compressed"] = manifest.compressed;
    j["encrypted"] = manifest.encrypted;
    
    auto created_time = manifest.created_at.time_since_epoch().count();
    auto updated_time = manifest.updated_at.time_since_epoch().count();
    j["created_at"] = created_time;
    j["updated_at"] = updated_time;
    
    j["chunks"] = nlohmann::json::array();
    for (const auto& chunk : manifest.chunks) {
        j["chunks"].push_back(serializeChunk(chunk));
    }
    
    // Statistics
    j["chunks_sent"] = manifest.chunks_sent;
    j["chunks_acked"] = manifest.chunks_acked;
    j["chunks_failed"] = manifest.chunks_failed;
    j["progress"] = manifest.progress;
    
    // Network metrics
    j["rtt_ms"] = manifest.rtt_ms;
    j["loss_rate"] = manifest.loss_rate;
    j["window_size"] = manifest.window_size;
    j["throughput_bps"] = manifest.throughput_bps;
    
    return j;
}

FileManifest ManifestManager::deserializeManifest(const nlohmann::json& j) {
    FileManifest manifest;
    manifest.file_id = j["file_id"];
    manifest.filename = j["filename"];
    manifest.filepath = j["filepath"];
    manifest.total_size = j["total_size"];
    manifest.chunk_size = j["chunk_size"];
    manifest.total_chunks = j["total_chunks"];
    manifest.file_hash = j.value("file_hash", "");
    manifest.mode = static_cast<TransferMode>(j["mode"]);
    manifest.compressed = j.value("compressed", false);
    manifest.encrypted = j.value("encrypted", false);
    
    auto created_time = j["created_at"].get<std::chrono::steady_clock::duration::rep>();
    auto updated_time = j["updated_at"].get<std::chrono::steady_clock::duration::rep>();
    manifest.created_at = std::chrono::steady_clock::time_point(
        std::chrono::steady_clock::duration(created_time));
    manifest.updated_at = std::chrono::steady_clock::time_point(
        std::chrono::steady_clock::duration(updated_time));
    
    manifest.chunks.clear();
    for (const auto& chunk_json : j["chunks"]) {
        manifest.chunks.push_back(deserializeChunk(chunk_json));
    }
    
    // Statistics
    manifest.chunks_sent = j.value("chunks_sent", 0);
    manifest.chunks_acked = j.value("chunks_acked", 0);
    manifest.chunks_failed = j.value("chunks_failed", 0);
    manifest.progress = j.value("progress", 0.0);
    
    // Network metrics
    manifest.rtt_ms = j.value("rtt_ms", 0.0);
    manifest.loss_rate = j.value("loss_rate", 0.0);
    manifest.window_size = j.value("window_size", 10);
    manifest.throughput_bps = j.value("throughput_bps", 0.0);
    
    return manifest;
}

} // namespace manifest
} // namespace transfer